%Code by Matthew B. Broschard
%12/01/19

function SessionAnalysis

clear all; clc;
%Trial information (from expData.trialMat & expData.respMat)
tFREQUENCY = 1;		
tORIENTATION = 2;
tCATEGORY = 3; CatA = 1; CatB = 2;
tRELEVANT_DISTANCE = 4;
tIRRELEVANT_DISTANCE = 5;
tRNDINDEX = 6;
tTRIAL_TYPE = 7; TRAINED = 1; TESTED = 2;
tREWARDRULE = 8;     	tALBR = 1; tARBL = 2;
tSUBGROUP = 9;           RB = 1; II = 2;
tCORRECTSIDE = 10;		LEFT = 1; RIGHT = 2;
tSTART_RT = 11;
tCHOICE_RT = 12;
tCHOICE_SIDE = 13;		LEFT = 1; RIGHT = 2;
tCORRECTNESS = 14;		CORRECT = 1; INCORRECT = 0;
tTOTAL_RT = 15;
tINDEX = 16;
tBLOCK = 17;
tTOOSLOW = 18;  YES = 1; NO = 0;

%load .mat file
[thisMAT thisROOT dummy] = uigetfile(pwd);
load([thisROOT thisMAT]);
HumanData = expData.trialMat(:,expData.trialMat(tTOOSLOW,:) ~= 1);
    
%% Accuracy
Results = [];
Results.Accuracy = [nanmean(HumanData(tCORRECTNESS,:)) nanmean(HumanData(tCORRECTNESS,HumanData(tCATEGORY,:)==1)) nanmean(HumanData(tCORRECTNESS,HumanData(tCATEGORY,:)==2))].* 100; %All, Category A, Category B

%% Reaction time
Results.ReactionTime = [nanmean(HumanData(tTOTAL_RT,:)) nanmean(HumanData(tTOTAL_RT,HumanData(tCATEGORY,:)==1)) nanmean(HumanData(tTOTAL_RT,HumanData(tCATEGORY,:)==2)); ... %TotalRT (Cue phase + Choice phase): All, Category A, Category B 
                        nanmean(HumanData(tCHOICE_RT,:)) nanmean(HumanData(tCHOICE_RT,HumanData(tCATEGORY,:)==1)) nanmean(HumanData(tCHOICE_RT,HumanData(tCATEGORY,:)==2))]; %Choice RT: All, Category A, Category B
                        
%% Response Bias
Results.ResponseBias = jkGetBias(HumanData(tCHOICE_SIDE,:));

%% Plot
figure('Position',[200 200 900 600]); 

%Accuracy
subplot(2,2,1);
bar(Results.Accuracy); ylabel(['Accuracy (%)']); xticklabels({'All' 'Category A' 'Category B'}); title(['Accuracy']); ylim([min(Results.Accuracy) - 10 max(Results.Accuracy) + 10]);

%Total reaction time
subplot(2,2,2);
bar(Results.ReactionTime(2,:)); ylabel(['Reaction Time (seconds)']); xticklabels({'All' 'Category A' 'Category B'}); title(['Reaction Time']); ylim([0 max(Results.ReactionTime(1,:)) + 1]);

%Response bias
subplot(2,2,3);
bar(Results.ResponseBias); ylabel(['Response Bias']); title(['Response Bias']); ylim([0 1]);
end %function SessionAnalysis

function [responseBias] = jkGetBias(inputMat);
	%Code by Jangjin Kim
	twoVals = [1 2];
	inputMat(isnan(inputMat)) = [];

	if numel(twoVals) > 2 | numel(twoVals) <= 0
		error;
	end	%numel(twoVals) > 2 | numel(twoVals) <= 0

	count1 = nansum(inputMat == twoVals(1));
	count2 = nansum(inputMat == twoVals(2));

	responseBias = abs(count1 - count2) / (count1 + count2);
end %[responseBias] = jkGetBias(inputMat);