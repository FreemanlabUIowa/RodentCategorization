function satisfied = jkSequenceCheck(inputVector, nALLOWEDrep)
%Check the trial sequence has only allowed numbers of repetitions
%Code by Jangjin Kim, 2013-June-18
%
%Input param definition
%inputVector [1 x n]	input sequence containing conditional info.
%nALLOWEDrep [1 x 1]	allowed numbers of repetitions of the same conditions

nALLOWEDrep = nALLOWEDrep + 1;
opMat = zeros(nALLOWEDrep, length(inputVector) - nALLOWEDrep + 1);

for opRUN = 1:1:nALLOWEDrep
	opMat(opRUN, :) = inputVector(1, opRUN:end - nALLOWEDrep + opRUN);
end %opRUN = 1:1:nALLOWEDrep

satisfied = ~any(find(sum(opMat) == 1 * nALLOWEDrep | sum(opMat) == 2 * nALLOWEDrep));