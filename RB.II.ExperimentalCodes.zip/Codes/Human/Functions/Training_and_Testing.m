%Code by Matt Broschard, 2018-June
%Inputs needed

%strSubID: subject ID
%thisREWRULE: counterbalances categories to response keys
%thisSUBGROUP: RuleBased = 1; Information Integration = 2;

function Training_and_Testing(strSubID, thisREWRULE, thisSUBGROUP)

%Design
nTRIALS = 2;           %Number of trials per block
TrainingBlocks = 2;     %Number of training blocks (each 80 trials)
TestingBlocks = 4;      %Number of testing blocks (each 80 trials)

%Trial Parameters
MaxRT = Inf;            %Maximum time to make a choice 
FeedbackDelay = 0.5;    %Delay between choice and presentation of feedback (seconds)
FeedbackInterval = 1;   %How long feedback is presented on the screen (seconds)
ITIMat = 0.8:.1:1.2;    %Inter trial interval

%Screen parameters
colScreen = [200 200 200] ./ 255;   %Color of screen
idScreen = Screen('Screens');
szScreen(1,:) = Screen(idScreen(1), 'Rect');
mainScreenPosition = [0 0 szScreen(1, 3) szScreen(1, 4)];
FontColor = 'k'; 

cx = szScreen(1,3)/2; cy = szScreen(1,4)/2; %Center x and y coordinate of the screen
XPosition = round(cx -(cx/3.2));            %Position for text
XPosition2 = cx - (cx/8);                   
XPosition3 = cx - (cx/2);

%Keyboard Parameters
outFlag = false;
KeyPressA = KbName('q');            %Category A
KeyPressB = KbName('p');            %Category B
KeyPressSpace = KbName('space');    %Trial Start

if thisREWRULE == 1, txtRewRule = ['Left(A) - Right(B)'];
else txtRewRule = ['Right(A) - Left(B)']; end	%thisREWRULE == 1

if thisSUBGROUP == 1, txtSubGroup = ['RB'];
elseif thisSUBGROUP == 2, txtSubGroup = ['II']; end %if thisSUBGROUP == 1

%trial info
tFREQUENCY = 1;		
tORIENTATION = 2;
tCATEGORY = 3; CatA = 1; CatB = 2;
tRELEVANT_DISTANCE = 4;
tIRRELEVANT_DISTANCE = 5;
tRNDINDEX = 6;
tTRIAL_TYPE = 7; TRAINED = 1; TESTED = 2;
tREWARDRULE = 8;     	tALBR = 1; tARBL = 2;
tSUBGROUP = 9;           RB = 1; II = 2;
tCORRECTSIDE = 10;		LEFT = 1; RIGHT = 2;
tSTART_RT = 11;
tCHOICE_RT = 12;
tCHOICE_SIDE = 13;		LEFT = 1; RIGHT = 2;
tCORRECTNESS = 14;		CORRECT = 1; INCORRECT = 0;
tTOTAL_RT = 15;
tINDEX = 16;
tBLOCK = 17;
tTOOSLOW = 18;  YES = 1; NO = 0;

%expData
expData.ProgramID = ['GaborPatches'];
expData.SubID = strSubID;
expData.date = date;
expData.time_st = clock;
expData.time_st = [num2str(expData.time_st(4)) ':' num2str(expData.time_st(5))];
expData.nTrials = 80;
expData.Correction = 1;	%all the time
expData.RewardRule = thisREWRULE;
expData.TxtRewardRule = txtRewRule;
expData.Subgroup = thisSUBGROUP;
expData.TxtSubgroup = txtSubGroup; 

%% Start Blocks
c = 1; 
trialMat = []; corrMat = [];

for block = 1:TrainingBlocks + TestingBlocks

blockStart = GetSecs;
if block == TrainingBlocks + 1 %First testing block
    trialMat = nan(18,nTRIALS);
else
    trialMat = [trialMat nan(18,nTRIALS)];
end %if block == TrainingBlocks + 1 %First testing block
    
%Get stimuli
if block <= TrainingBlocks
    XSD = 4.041; 
    sessionMODE = 1; 
    expData.numBlock = TrainingBlocks;
elseif block > TrainingBlocks
    XSD = 8.082; 
    sessionMODE = 2; 
    expData.numBlock = 4; 
end %if block <= TrainingBlocks

Visualize = 0; Matrix = 1;
Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix, sessionMODE);

trialMat(tFREQUENCY : tTRIAL_TYPE, c:c+nTRIALS-1) = Stimuli; 
trialMat(tREWARDRULE, c:c+nTRIALS-1) = thisREWRULE; 
trialMat(tSUBGROUP, c:c+nTRIALS-1) = thisSUBGROUP;
trialMat(tINDEX,c:c+nTRIALS-1) = 1:nTRIALS;
trialMat(tBLOCK,c:c+nTRIALS-1) = block;

%Correct side
if thisREWRULE == 1, trialMat(tCORRECTSIDE, c:c+nTRIALS-1) = trialMat(tCATEGORY, c:c+nTRIALS-1);
elseif thisREWRULE == 2, trialMat(tCORRECTSIDE, trialMat(tCATEGORY,:) == LEFT) = RIGHT; trialMat(tCORRECTSIDE, trialMat(tCATEGORY,:) == RIGHT) = LEFT; end %if thisREWRULE == 1

%File name
if block <= TrainingBlocks
    fnameMat = [expData.ProgramID '-Training-' txtSubGroup '-Block-' num2str(block) '-Subject-' num2str(expData.SubID) '-' expData.date '.mat'];
elseif block > TrainingBlocks
    fnameMat = [expData.ProgramID '-Testing-' txtSubGroup '-Block-' num2str(block - TrainingBlocks) '-Subject-' num2str(expData.SubID) '-' expData.date '.mat'];
end %if block <= TrainingBlocks

%Prep. screens
pointerCol = nan(16, 16);
figScreens = figure('Color', colScreen, 'Position', mainScreenPosition, 'Pointer', 'custom', 'PointerShapeCData', pointerCol, ... 
			'menubar', 'none', 'resize', 'off', 'Name', ['Screen1'], 'Visible', 'on');
subplot('Position', [0 0 1 1], 'Color', colScreen)
set(gca, 'XLim', [0 szScreen(1, 3)], 'YLim', [0 szScreen(1, 4)], 'XTick', [], 'YTick', []); axis off;

%Loop across trials
for trialRUN = c:1:c+nTRIALS-1
	%% Start trial
    text(XPosition,cy,'Press Spacebar to continue','Color',FontColor,'FontSize', 32); %Press spacebar
    go = true; thisStartOnset = GetSecs;
	while go
		FlushEvents('keyDown');
		[keyDown endSecs keyCode] = KbCheck;
		if keyDown
			if keyCode(KeyPressSpace) %Sparsebar is pressed
                trialMat(tSTART_RT,trialRUN) = endSecs - thisStartOnset;
                outFlag = true; go = false; %Exit while loop
            end	%if keyCode(KeyPressSpace) %Sparsebar is pressed
		end	%if keyDown
	end	%while go
    
	%% Cue-phase
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); 
    jkGenGaborWithFilter(figScreens(1), trialMat(tFREQUENCY,trialRUN), trialMat(tORIENTATION,trialRUN), szScreen); drawnow expose; %Present Gabor patch
	
    %% Choice
    go = true; thisCueOnset = GetSecs;
	while go
		FlushEvents('keyDown');
		[keyDown endSecs keyCode] = KbCheck;
		if keyDown
			if keyCode(KeyPressA) | keyCode(KeyPressB) %q or p is pressed
                trialMat(tCHOICE_RT,trialRUN) = endSecs - thisCueOnset;
                trialMat(tTOTAL_RT,trialRUN) = trialMat(tSTART_RT,trialRUN) + trialMat(tCHOICE_RT,trialRUN);
                outFlag = true; go = false; %Exit while loop
                if 	keyCode(KeyPressA)
                    trialMat(tCHOICE_SIDE,trialRUN) = LEFT;
                elseif keyCode(KeyPressB)
                    trialMat(tCHOICE_SIDE,trialRUN) = RIGHT;
                end %if 	keyCode(KeyPressA)
			end	%if keyCode(KeyPressA) | keyCode(KeyPressB) %q or p is pressed
		end	%if keyDown
        
        if (GetSecs - thisCueOnset) > MaxRT %Too slow to respond
            go = false; %Break the while loop
            jkCleanFigScreen(figScreens(1), colScreen, szScreen); drawnow expose;
            text(XPosition2,cy,'Too Slow!','Color','r','FontSize', 32); %Too slow!
            trialMat(tTOOSLOW,trialRUN) = 1;
            pause(1);
        end %if (GetSecs - thisCueOnset) > MaxRT %Too slow to respond
	end	%while go
	
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); drawnow expose;
	
	%% Reward-phase
	pause(FeedbackDelay);
    if trialMat(tTOOSLOW,trialRUN) ~= 1
        if trialMat(tCORRECTSIDE,trialRUN) == trialMat(tCHOICE_SIDE,trialRUN) | ... %Correct
           trialMat(tTRIAL_TYPE,trialRUN) == 2 %Or it's a testing trial
           text(XPosition2,cy,'Correct!','Color','g','FontSize', 32); 
           
           pause(FeedbackInterval);
        else 
            text(XPosition2,cy,'Wrong!','Color','r','FontSize', 32);
            trialMat(tCORRECTNESS,trialRUN) = 0;
            pause(FeedbackInterval);
        end %if trialMat(tCORRECTSIDE,trialRUN) == trialMat(tCHOICE_SIDE,trialRUN) | ... %Correct
    end %if trialMat(tTOOSLOW,trialRUN) ~= 1
    
    if trialMat(tCORRECTSIDE,trialRUN) == trialMat(tCHOICE_SIDE,trialRUN)
        trialMat(tCORRECTNESS,trialRUN) = 1;
    else
        trialMat(tCORRECTNESS,trialRUN) = 0;
    end %if trialMat(tCORRECTSIDE,trialRUN) == trialMat(tCHOICE_SIDE,trialRUN)
    
	%% ITI
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); drawnow expose;
    ITIidx = randperm(length(ITIMat)); ITI = ITIMat(ITIidx(1));
    pause(ITI);
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); drawnow expose;
    
end	%trialRUN = 1:1:nTRIALS

blockEnd = GetSecs;
text(XPosition3, cy, ['End of Block ' num2str(block) '. Press the Spacebar to continue.'], 'Color', FontColor, 'FontSize', 32);

%End of block
szFONT = 9;
titleXst = -1; textXst = -.5;
picID = figure('Color', [1 1 1], 'Position', [0 0 1200 375], 'menubar', 'none');
text(textXst, 9, ['--------------------------------------------------------------------------']);
text(textXst, 8, ['SubID: ' num2str(strSubID) ' [' expData.date ']']);
text(textXst, 7, ['Ellapsed time: ' df2str((blockEnd - blockStart)/60, 2) ' min']);
text(textXst, 6, ['Block Number: ' num2str(block) ' of ' num2str(TrainingBlocks + TestingBlocks)]);
text(textXst, 5, ['--------------------------------------------------------------------------']);
set(gca, 'XLim', [0 10], 'YLim', [0 10], 'XTick', [], 'YTick', [], 'FontSize', szFONT); axis off;

%Save expData
expData.trialMat = trialMat;
expData.corrMat = corrMat;
expData.time_ed = clock;
expData.time_ed = [num2str(expData.time_ed(4)) ':' num2str(expData.time_ed(5))];
expData.duration = (blockEnd - blockStart) / 60;
save(fnameMat, 'expData');

%Wait for response to go to next block
    go = true;
	while go
		FlushEvents('keyDown');
		[keyDown endSecs keyCode] = KbCheck;
		if keyDown
			if keyCode(KeyPressSpace)
                outFlag = true; go = false;
			end	%keyCode(IsOut)
		end	%keyDown
	end	%while go
    
try close(picID);catch; end %try close(picID);
jkCleanFigScreen(figScreens(1), colScreen, szScreen); drawnow expose;
close(figScreens);

if block == TrainingBlocks, c = 1;
else, c = c + nTRIALS; end %if block == TrainingBlocks

end %for block = 1:TrainingBlocks + TestingBlocks
end	%function Training_and_Testing(strSubID, thisREWRULE, thisSUBGROUP)