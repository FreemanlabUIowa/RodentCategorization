function [responseBias] = jkGetBias(inputMat);
%Code by Jangjin Kim
twoVals = [1 2];
inputMat(isnan(inputMat)) = [];

if numel(twoVals) > 2 | numel(twoVals) <= 0
	error;
end	%numel(twoVals) > 2 | numel(twoVals) <= 0

count1 = nansum(inputMat == twoVals(1));
count2 = nansum(inputMat == twoVals(2));

responseBias = abs(count1 - count2) / (count1 + count2);