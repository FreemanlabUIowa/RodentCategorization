% Codes by Matthew B. Broschard
% Finalized 11/5/19
%
%Inputs needed: 
%   1) thisSUBGROUP: 
%       Rule-Based task with spatial frequency as the relevant dimension = 1;       
%       Information Intregration task with positive slope = 2 
%
%   2) nTRIALS: number of total trials for the distributions (typically 80)
%
%   3) XSD: standard deviation along the relevant dimension/axis. For training
%      sessions, this is 4.041. For testing sessions, this is 8.082
%
%   4) Visualize: graph the distributions? YES = 1, NO = 0
%
%   5) Matrix: output a matrix with the stimulus information? YES = 1, NO = 0

function Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix, sessionMODE)
    ClockRandSeed; %generate random numbers

%Parameters
    uA = 35.86;                     %X mean of category A
    uB = 64.14;                     %X mean of category B
    YSD = 18.856;                   %Y Standard deviation
    Center = 50;                    %center of the stimulus space
    C1 = -20; C2 = 50;              %Constants used to recenter distributions after rotation (see below)
    RepeatLimit = 3;                %Limit on the number of consecutive trials that have the same category membership
    RB = 1; II = 2;                 %Subgroup names

    %trial information (by row)
    FREQUENCY = 1; 
    ORIENTATION = 2; 
    CATEGORY = 3; %A = 1, B = 2
    RELEVANT_DISTANCE = 4; %Distance from the category mean along the
    %relevant dimension/axis. Positive distance means closer to the category 
    %boundary. Negative distance means farther from the category boundary
    IRRELEVANT_DISTANCE = 5; %Distance from the category mean along the 
    %irrelevant dimension/axis. Positive distance means above '50'. Negative distance means below '50'. 
    RNDINDEX = 6; %Randomized index
    TRIAL_TYPE = 7; %Training = 1; Testing = 2;
    
%Generate RB distributions
     go = true;
     while go %Make sure no trials exceed the boundary
     %Create Distributions
     
     
     %Category 'A'
     Distributions(FREQUENCY:CATEGORY, 1:nTRIALS/2) = ([normrnd(uA, XSD, nTRIALS/2, 1)'; ...    %Frequency values
                                                        normrnd(Center, YSD, nTRIALS/2,1)'; ... %Orientation values
                                                        ones(1,nTRIALS/2);]);                   %Category A
                                                    
     %Category 'B'                                               
     Distributions(FREQUENCY:CATEGORY, (nTRIALS/2) + 1: nTRIALS) = ([normrnd(uB, XSD, nTRIALS/2, 1)'; ...    %Frequency values
                                                                     normrnd(Center, YSD, nTRIALS/2,1)'; ... %Orientation values
                                                                     ones(1,nTRIALS/2) + 1;]);               %Category B
     
     %Calculate distance according to the relevant dimension
     Distributions(RELEVANT_DISTANCE, 1:nTRIALS/2) = Distributions(FREQUENCY,1:nTRIALS/2) - uA; %Category A
     Distributions(RELEVANT_DISTANCE, (nTRIALS/2) + 1 : nTRIALS) = uB - Distributions(FREQUENCY,(nTRIALS/2) + 1 : nTRIALS); %Category B
     
     %Calculate distance according to the irrelevant dimension
     Distributions(IRRELEVANT_DISTANCE, :) = Distributions(ORIENTATION,:) - Center;
     
     %Add trial type information
     if sessionMODE == 1 %Training
        Distributions(TRIAL_TYPE,:) = 1; %Trained
     elseif sessionMODE == 2 %Testing
        Distributions(TRIAL_TYPE,abs(Distributions(RELEVANT_DISTANCE,:)) <= XSD) = 1; %Trained
        Distributions(TRIAL_TYPE,abs(Distributions(RELEVANT_DISTANCE,:)) > XSD) = 2; %Tested
     end %if sessionMODE == 1 %Training
     
     %Check if points exceed the category boundary and/or the limits of the
     %stimulus space (i.e., 0 and 100)
         if max(Distributions(RELEVANT_DISTANCE,:)) < (Center - uA) && ...
            min(Distributions(FREQUENCY,:)) > 0 && max(Distributions(FREQUENCY,:)) < 100 && min(Distributions(ORIENTATION,:)) > 0 && max(Distributions(ORIENTATION,:)) < 100
            go = false; %breaks the while loop
         end %if max(Distributions(RELEVANT_DISTANCE,:)) < (Center - uA) && ...
     end %while go 

    %Rotate Points Accordingly
    D = Distributions;
    if thisSUBGROUP == II 
        theta = pi/4; %45 degrees clockwise
        D(FREQUENCY:ORIENTATION,:) = ([Distributions(FREQUENCY,:) .* cos((-1)* theta) - Distributions(ORIENTATION,:) .* sin((-1)*theta) + C1; ... 
                                       Distributions(ORIENTATION,:).*cos((-1)*theta) + Distributions(FREQUENCY,:) .* sin((-1)*theta) + C2;]); 
    end %if thisSUBGROUP == II 

%Visualize?
    if Visualize == 1
        scatter(D(FREQUENCY,D(CATEGORY,:)==1), D(ORIENTATION,D(CATEGORY,:)==1),'b'); %Category A
        hold on; scatter(D(FREQUENCY,D(CATEGORY,:)==2), D(ORIENTATION,D(CATEGORY,:)==2),'r'); %Category B
        xlim([0 100]); ylim([0 100]); xlabel(['Frequency']); ylabel(['Orientation']);
    end %if Visualize == 1
    
%Matrix?
    if Matrix == 1
    %This code randomizes the trial order and ensures the same category
        %does not repeat more than the RepeatLimit consecutively
            go = true;
            while go 
                RI = randperm(nTRIALS);
                for i = 1:1:nTRIALS
                    check(1,i) = D(CATEGORY,RI(i)); 
                end %for i = 1:1:nTRIALS
                res = jkSequenceCheck(check,RepeatLimit); %this number can be changed (see jkSequenceCheck function below)
                if res
                   go = false;
                end %if res
            end % while go 

        %Create the matrix
         for i = 1:1:nTRIALS
             Stimuli(FREQUENCY:TRIAL_TYPE,i) = ([D(FREQUENCY,RI(i)); D(ORIENTATION,RI(i)); D(CATEGORY,RI(i)); D(RELEVANT_DISTANCE, RI(1,i)); D(IRRELEVANT_DISTANCE, RI(1,i)); RI(i); D(TRIAL_TYPE, RI(i))]);
         end %for i = 1:1:nTRIALS
    end %if Matrix == 1

end %function Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix, sessionMODE)

function satisfied = jkSequenceCheck(inputVector, nALLOWEDrep)
    %Check the trial sequence has only allowed numbers of repetitions
    %Code by Jangjin Kim, 2013-June-18
    %
    %Input param definition
    %inputVector [1 x n]	input sequence containing conditional info.
    %nALLOWEDrep [1 x 1]	allowed numbers of repetitions of the same conditions

    nALLOWEDrep = nALLOWEDrep + 1;
    opMat = zeros(nALLOWEDrep, length(inputVector) - nALLOWEDrep + 1);

    for opRUN = 1:1:nALLOWEDrep
    	opMat(opRUN, :) = inputVector(1, opRUN:end - nALLOWEDrep + opRUN);
    end %opRUN = 1:1:nALLOWEDrep

    satisfied = ~any(find(sum(opMat) == 1 * nALLOWEDrep | sum(opMat) == 2 * nALLOWEDrep));
end %satisfied = jkSequenceCheck(inputVector, nALLOWEDrep)