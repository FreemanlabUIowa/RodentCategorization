function [txtUPTO2DECPOINT] = df2str(inputVAL, decimalpoint)
%Transform decimal fraction to text (up to n-th dec point)
%Code by Jangjin Kim, 2016-June-1

if nargin == 1
	decimalpoint = 2;
end	%nargin == 1

txtUPTO2DECPOINT = num2str(round(inputVAL * 10^decimalpoint) / 10^decimalpoint);