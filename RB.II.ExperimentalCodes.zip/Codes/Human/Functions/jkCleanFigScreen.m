function jkCleanFigScreen(screenH, colScreen, szScreen)
%Code by Jin Kim
%set(0, 'CurrentFigure', screenH); 
clf;
subplot('Position', [0 0 1 1], 'Color', colScreen)
set(gca, 'XLim', [0 szScreen(1, 3)], 'YLim', [0 szScreen(1, 4)], 'XTick', [], 'YTick', [], 'YDir', 'rev'); axis off;