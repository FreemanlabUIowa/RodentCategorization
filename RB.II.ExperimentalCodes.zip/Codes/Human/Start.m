%initialization
clear all; close all; fclose all; clc;

%Add exp functions to path
addpath([pwd '\Functions']);

%Set random seed
warning off; ClockRandSeed; warning on;

thisSubID = input('Subject Number?');
thisREWRULE = mod(floor((thisSubID - 1) / 4), 2) + 1;
thisSUBGROUP = mod(floor((thisSubID - 1) / 1), 4) + 1;

FlagStart = input(['Press any key to start:: '], 's');
ListenChar(2); % Suppress output to command line
Training_and_Testing(thisSubID, thisREWRULE, thisSUBGROUP);
ListenChar(0); % Unlock output to command line