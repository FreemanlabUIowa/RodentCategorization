%Code by Matthew B. Broschard
%12/01/19

function thisGabor = GaborPatch(thisFREQUENCY, thisORIENTATION)

szWIDTH = 238; %Size in pixels

gauSigma = 45; gauPhase = 2 * pi; gauTrim = .005;

X = 1:szWIDTH; X = (X ./ szWIDTH) - .5;
[Xm Ym] = meshgrid(X, X);

%Frequency
freq = thisFREQUENCY / 30 + 1; %According to Smith et al. 2012
Xf = X * freq * 2 * pi;

%Orientation
ori = (thisORIENTATION * pi/200) + pi/9; %According to Smith et al. 2012
XYori = [Xm * cos(ori) + Ym * sin(ori)];
XYf = XYori * freq * 2 * pi;
grating = sin(XYf + gauPhase);

gauS = gauSigma / szWIDTH;
Xg = exp(-((X.^2)) ./ (2 * gauS^2));
Xg = normpdf(X, 0, (20 / szWIDTH)); 
Xg = Xg / max(Xg);
thisGauss = exp(-(((Xm.^2) + (Ym.^2)) ./ (2 * gauS^2)));
thisGauss(thisGauss < gauTrim) = 0;

thisGabor = grating .* thisGauss; 
thisGabor = thisGabor ./ max(max(thisGabor)); 
thisGabor = imshow(thisGabor + (200 / 255));
title(['Frequency = ' num2str(thisFREQUENCY) ', Orientation = ' num2str(thisORIENTATION)]);
