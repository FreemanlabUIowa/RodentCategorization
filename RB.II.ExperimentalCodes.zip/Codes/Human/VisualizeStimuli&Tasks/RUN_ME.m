%Code by Matt Broschard
%11/28/19
clear all; clc;

%Row information from output matrices
FREQUENCY = 1;
ORIENTATION = 2;
CATEGORY = 3; %A = 1, B = 2
RELEVANT_DISTANCE = 4; %Distance from the category mean along the
    %relevant dimension/axis. Positive distance means closer to the category 
    %boundary. Negative distance means farther from the category boundary
IRRELEVANT_DISTANCE = 5; %Distance from the category mean along the 
    %irrelevant dimension/axis. Positive distance means above '50'. Negative distance means below '50'. 
RNDINDEX = 6; %Randomized index

%% Rule Based (RB)
figure('Position', [200 200 900 600]);

%RB Training
subplot(2,2,1); thisSUBGROUP = 1; nTRIALS = 80; XSD = 4.041; Visualize = 1; Matrix = 1; sessionMODE = 1;
RBTraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix, sessionMODE);
title(['RB: Training']);

%RB Testing
subplot(2,2,2); thisSUBGROUP = 1; nTRIALS = 80; XSD = 8.082; Visualize = 1; Matrix = 1; sessionMODE = 2;
RBTesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix,sessionMODE);
title(['RB: Testing']);

%% Information Integration (II)
%II Training
subplot(2,2,3); thisSUBGROUP = 2; nTRIALS = 80; XSD = 4.041; Visualize = 1; Matrix = 1; sessionMODE = 1;
IITraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix,sessionMODE);
title(['II: Training']);

%II Testing
subplot(2,2,4); thisSUBGROUP = 2; nTRIALS = 80; XSD = 8.082; Visualize = 1; Matrix = 1; sessionMODE = 2;
IITesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix,sessionMODE);
title(['II: Testing']);

%% Generate sample Gabor patches
figure('Position', [200 200 900 600]);
subplot(2,2,1); GaborPatch(10,50); 
subplot(2,2,2); GaborPatch(90,50); 
subplot(2,2,3); GaborPatch(50,10); 
subplot(2,2,4); GaborPatch(50,90);