%These are experimental codes to implement and analyze Rule-based (RB) and 
%Information Integration (II) categorization sessions intended for rodent and 
%human participants. In these tasks, participants are presented with distributions 
%of category exemplars. On each learning trial, the participant must decide 
%the category membership of a category exemplar randomly pulled from the 
%category distributions. Feedback guides learning within and across training 
%sessions. A full description of the tasks and the experimental design can
%be found here:

%Broschard, M. B., Kim, J., Love, B. C., Wasserman, E. A., & Freeman, J. H. (2019). Selective attention in rat visual category learning. Learning & Memory, 26(3), 84�92. doi: 10.1101/lm.048942.118

%http://learnmem.cshlp.org/content/26/3/84.full

%Two versions of the tasks are provided. The first is applicable for rodent 
%subjects and utilizes a touchscreen apparatus. The second is applicable for 
%human participants and can be run on any desktop/laptop. For each version, 
%scripts are provided that 1) initiate an experimental session (�Start.m�), 
%2) visualize representative exemplars and task design (VisualizeStimuli&Task), 
%and 3) demonstrate the basic analysis of the output session data (Analysis). 

%Experimental codes require MATLAB and Psychtoolbox. Codes are written by 
%the Neuroscience of Learning Lab at the University of Iowa. Please see 
%licensure for proper citation if the obtained codes are implemented in 
%future publication.
