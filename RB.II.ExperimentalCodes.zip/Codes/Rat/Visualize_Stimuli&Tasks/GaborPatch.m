%Code by Matthew B. Broschard
%12/01/19

function thisGabor = GaborPatch(thisFREQUENCY, thisORIENTATION) %Frequency, Orientation

szWIDTH = 238; %Size in pixels

gauSigma = 23.8; gauPhase = 2 * pi; gauTrim = .005;

X = 1:szWIDTH; X = (X ./ szWIDTH) - .5;
[Xm Ym] = meshgrid(X, X);

%Frequency
freq = thisFREQUENCY / szWIDTH * (szWIDTH / 6);
Xf = X * freq * 2 * pi;

%Orientation
ori = (thisORIENTATION / 360) * 2 * pi;
XYori = [Xm * cos(ori) + Ym * sin(ori)];
XYf = XYori * freq * 2 * pi;
grating = sin(XYf + gauPhase);

gauS = gauSigma / szWIDTH;
thisGauss = ((((Xm.^2) + (Ym.^2)) .* (2 * gauS^2))); 
thisGauss(thisGauss < gauTrim) = gauTrim; thisGauss(thisGauss > gauTrim) = 0; 

thisGabor = grating .* thisGauss;  
thisGabor = thisGabor ./ max(max(thisGabor)); 
thisGabor = imshow(thisGabor + (200 / 255)); 
title(['Frequency = ' num2str(thisFREQUENCY) ', Orientation = ' num2str(thisORIENTATION)]);
