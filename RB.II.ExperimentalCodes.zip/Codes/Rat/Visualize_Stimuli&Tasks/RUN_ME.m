%Code by Matt Broschard
%11/28/19

clear all; clc;

%Row information from output matrices
FREQUENCY = 1;
ORIENTATION = 2;
CATEGORY = 3; %A = 1, B = 2
RELEVANT_DISTANCE = 4; %Distance from the category mean along the
    %relevant dimension/axis. Positive distance means closer to the category 
    %boundary. Negative distance means farther from the category boundary
IRRELEVANT_DISTANCE = 5; %Distance from the category mean along the 
    %irrelevant dimension/axis. Positive distance means above '50'. Negative distance means below '50'. 
RNDINDEX = 6; %Randomized index

%% Rule Based (RB)
%RB Frequency Training
figure('Position', [200 200 900 600]);;
subplot(2,2,1); thisSUBGROUP = 1; nTRIALS = 80; XSD = 2.5; Visualize = 1; Matrix = 1;
RBFTraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['RBF: Training']);

%RB Frequency Testing
subplot(2,2,2); thisSUBGROUP = 1; nTRIALS = 80; XSD = 10; Visualize = 1; Matrix = 1;
RBFTesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['RBF: Testing']);

%RB Orientation Training
subplot(2,2,3); thisSUBGROUP = 2; nTRIALS = 80; XSD = 2.5; Visualize = 1; Matrix = 1;
RBOTraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['RBO: Training']);

%RB Orientation Testing
subplot(2,2,4); thisSUBGROUP = 2; nTRIALS = 80; XSD = 10; Visualize = 1; Matrix = 1;
RBOTesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['RBO: Testing']);

%% Information Integration (II)
%II Positive Slope Training
figure('Position', [200 200 900 600]);;
subplot(2,2,1); thisSUBGROUP = 3; nTRIALS = 80; XSD = 2.5; Visualize = 1; Matrix = 1;
IIPTraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['IIP: Training']);

%II Positive Slope Testing
subplot(2,2,2); thisSUBGROUP = 3; nTRIALS = 80; XSD = 10; Visualize = 1; Matrix = 1;
IIPTesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['IIP: Testing']);

%II Negative Slope Training
subplot(2,2,3); thisSUBGROUP = 4; nTRIALS = 80; XSD = 2.5; Visualize = 1; Matrix = 1;
IINTraining = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['IIN: Training']);

%II Negative Slope Testing
subplot(2,2,4); thisSUBGROUP = 4; nTRIALS = 80; XSD = 10; Visualize = 1; Matrix = 1;
IINTesting = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);
title(['IIN: Testing']);


%% Generate sample Gabor patches
figure('Position',[200 200 900 600]);
subplot(2,2,1); GaborPatch(10,50); 
subplot(2,2,2); GaborPatch(90,50); 
subplot(2,2,3); GaborPatch(50,10); 
subplot(2,2,4); GaborPatch(50,90);