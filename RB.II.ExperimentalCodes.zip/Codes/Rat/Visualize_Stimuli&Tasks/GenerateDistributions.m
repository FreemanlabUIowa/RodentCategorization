% Codes by Matthew B. Broschard
% Finalized 11/5/19
%
%Inputs needed: 
%   1) thisSUBGROUP: 
%       Rule-Based task with spatial frequency as the relevant dimension = 1;
%       Rule-Based task with orientation as the relevant dimension = 2;
%       Information Intregration task with positive slope = 3
%       Information Integration task with negative slope = 4
%
%   2) nTRIALS: number of total trials for the distributions (typically 80)
%
%   3) XSD: standard deviation along the relevant dimension/axis. For training
%      sessions, this is typically 2.5. For testing sessions, this is 10
%
%   4) Visualize: graph the distributions? YES = 1, NO = 0
%
%   5) Matrix: output a matrix with the stimulus information? YES = 1, NO = 0

function Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix)
    %ClockRandSeed; %generate random numbers
    
    %Parameters
    uA = 30;                                %X mean of category A
    uB = 70;                                %X mean of category B
    YSD = 20;                               %Y Standard deviation
    Center = 50;                            %center of the stimulus space
    C1 = 100; C2 = -20; C3 = 50;            %Constants used to recenter distributions after rotation (see below)
    RepeatLimit = 3;                        %Limit on the number of consecutive trials that have the same category membership
    RBF = 1; RBO = 2; IIP = 3; IIN = 4;     %Subgroup names
    
    %trial information (by row)
    FREQUENCY = 1; 
    ORIENTATION = 2; 
    CATEGORY = 3; %A = 1, B = 2
    RELEVANT_DISTANCE = 4; %Distance from the category mean along the
        %relevant dimension/axis. Positive distance means closer to the category 
        %boundary. Negative distance means farther from the category boundary
    IRRELEVANT_DISTANCE = 5; %Distance from the category mean along the 
        %irrelevant dimension/axis. Positive distance means above '50'. Negative distance means below '50'. 
    RNDINDEX = 6; %Randomized index
    
     %Generate RBF training distributions
     go = true;
     while go 
     %Create Distributions
     
     %Category 'A'
     Distributions(FREQUENCY:CATEGORY, 1:nTRIALS/2) = ([normrnd(uA, XSD, nTRIALS/2, 1)'; ...    %Frequency values
                                                        normrnd(Center, YSD, nTRIALS/2,1)'; ... %Orientation values
                                                        ones(1,nTRIALS/2);]);                   %Category A
                                                    
     %Category 'B'                                               
     Distributions(FREQUENCY:CATEGORY, (nTRIALS/2) + 1: nTRIALS) = ([normrnd(uB, XSD, nTRIALS/2, 1)'; ...    %Frequency values
                                                                     normrnd(Center, YSD, nTRIALS/2,1)'; ... %Orientation values
                                                                     ones(1,nTRIALS/2) + 1;]);               %Category B
     
     %Calculate distance according to the relevant dimension
     Distributions(RELEVANT_DISTANCE, 1:nTRIALS/2) = Distributions(FREQUENCY,1:nTRIALS/2) - uA; %Category A
     Distributions(RELEVANT_DISTANCE, (nTRIALS/2) + 1 : nTRIALS) = uB - Distributions(FREQUENCY,(nTRIALS/2) + 1 : nTRIALS); %Category B
     
     %Calculate distance according to the irrelevant dimension
     Distributions(IRRELEVANT_DISTANCE, :) = Distributions(ORIENTATION,:) - Center;
      
     %Check if points exceed the category boundary and/or the limits of the
     %stimulus space (i.e., 0 and 100)
         if max(Distributions(RELEVANT_DISTANCE,:)) < (Center - uA) && ...
            min(Distributions(FREQUENCY,:)) > 0 && max(Distributions(FREQUENCY,:)) < 100 && min(Distributions(ORIENTATION,:)) > 0 && max(Distributions(ORIENTATION,:)) < 100
            go = false; %breaks the while loop
         end %if max(Distributions(RELEVANT_DISTANCE,:)) < (Center - uA) && ...
     end %while go 

    %Rotate points accordingly
    D = Distributions;
    if thisSUBGROUP == RBF
        %N/A
    elseif thisSUBGROUP == RBO 
        theta = - pi/2; %90 degrees 
        D(FREQUENCY:ORIENTATION,:) = ([Distributions(FREQUENCY,:) .* cos((-1)*theta) - Distributions(ORIENTATION,:) .* sin((-1)*theta) + C1; ... 
                                      Distributions(ORIENTATION,:).*cos((-1)*theta) + Distributions(FREQUENCY,:) .* sin((-1)*theta);]);
    elseif thisSUBGROUP == IIP 
        theta = pi/4; %45 degrees clockwise
        D(FREQUENCY:ORIENTATION,:) = ([Distributions(FREQUENCY,:) .* cos((-1)* theta) - Distributions(ORIENTATION,:) .* sin((-1)*theta) + C2; ... 
                                       Distributions(ORIENTATION,:).*cos((-1)*theta) + Distributions(FREQUENCY,:) .* sin((-1)*theta) + C3;]); 
    elseif thisSUBGROUP == IIN
        theta = (-1) * pi/4; %45 degrees counterclockwise
        D(FREQUENCY:ORIENTATION,:) = ([Distributions(FREQUENCY,:) .* cos((-1)* theta) - Distributions(ORIENTATION,:) .* sin((-1)*theta) + C3; ... 
                                       Distributions(ORIENTATION,:).*cos((-1)*theta) + Distributions(FREQUENCY,:) .* sin((-1)*theta) + C2; ]); 
    end %if thisSUBGROUP == RBF
    
    %Visualize?
    if Visualize == 1 %Yes
        scatter(D(FREQUENCY,D(CATEGORY,:)==1), D(ORIENTATION,D(CATEGORY,:)==1),'b'); %Category A
        hold on; scatter(D(FREQUENCY,D(CATEGORY,:)==2), D(ORIENTATION,D(CATEGORY,:)==2),'r'); %Category B
        xlim([0 100]); ylim([0 100]); xlabel(['Frequency']); ylabel(['Orientation']);
    end %if Visualize == 1 %Yes

    %Matrix?
    if Matrix == 1 %Yes
        %This code randomizes the trial order and ensures the same category
        %does not repeat more than the RepeatLimit consecutively
            go = true;
            while go 
                RI = randperm(nTRIALS);
                for i = 1:1:nTRIALS
                    check(1,i) = D(CATEGORY,RI(i)); 
                end %for i = 1:1:nTRIALS
                res = jkSequenceCheck(check,RepeatLimit); %this number can be changed (see jkSequenceCheck function below)
                if res
                   go = false;
                end %if res
            end %while go 

        %Create the matrix
         for i = 1:1:nTRIALS
             Stimuli(FREQUENCY:RNDINDEX,i) = ([D(FREQUENCY,RI(i)); D(ORIENTATION,RI(i)); D(CATEGORY,RI(i)); D(RELEVANT_DISTANCE, RI(1,i)); D(IRRELEVANT_DISTANCE, RI(1,i)); RI(i);]);
         end %for i = 1:1:nTRIALS
    end %if Matrix == 1 %Yes

end %function Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix)

function satisfied = jkSequenceCheck(inputVector, nALLOWEDrep)
    %Check the trial sequence has only allowed numbers of repetitions
    %Code by Jangjin Kim, 2013-June-18
    %
    %Input param definition
    %inputVector [1 x n]	input sequence containing conditional info.
    %nALLOWEDrep [1 x 1]	allowed numbers of repetitions of the same conditions

    nALLOWEDrep = nALLOWEDrep + 1;
    opMat = zeros(nALLOWEDrep, length(inputVector) - nALLOWEDrep + 1);

    for opRUN = 1:1:nALLOWEDrep
    	opMat(opRUN, :) = inputVector(1, opRUN:end - nALLOWEDrep + opRUN);
    end %opRUN = 1:1:nALLOWEDrep

    satisfied = ~any(find(sum(opMat) == 1 * nALLOWEDrep | sum(opMat) == 2 * nALLOWEDrep));
end %satisfied = jkSequenceCheck(inputVector, nALLOWEDrep)