%Code by Matthew B. Broschard
%12/01/19

function SessionAnalysis

%Trial information (from expData.trialMat & expData.respMat)
tINDEX = 1; %1:nTRIALS
tTASKTYPE = 2; RB = 1; II = 2;
tSUBGROUP = 3; RBF = 1; RBO = 2; IIP = 3; IIN = 4;
tFREQUENCY = 4;
tORIENTATION = 5;
tCATEGORY = 6; nCATEGORY = 2; CatA = 1; CatB = 2;
tRELEVANT_DISTANCE = 7;
tIRRELEVANT_DISTANCE = 8;
tRNDINDEX = 9;
tCORRECTSIDE = 10;  LEFT = 1; RIGHT = 2;
tSTAR_X = 11;
tSTAR_Y = 12;
tSTAR_RT = 13;
tCUE_RESP1 = 14; PRESENT = 1; ABSENT = 0;
tCUE_X1 = 15;
tCUE_Y1 = 16;
tCUE_RT1 = 17;			%CueOnset to 1stTouch
tCUE_RESP2 = 18; PRESENT = 1; ABSENT = 0;
tCUE_X2 = 19;
tCUE_Y2 = 20;
tCUE_RT2 = 21;			%CueOnset to 2ndTouch
tCUE_RESP3 = 22; PRESENT = 1; ABSENT = 0;
tCUE_X3 = 23;
tCUE_Y3 = 24;
tCUE_RT3 = 25;			%CueOnset to 3rdTouch
tCHOICE_RESP = 26; PRESENT = 1; ABSENT = 0;
tCHOICE_X = 27;
tCHOICE_Y = 28;
tCHOICE_RT = 29;
tCHOICE_SIDE = 30;		LEFT = 1; RIGHT = 2;
tREWARD_RESP = 31; PRESENT = 1; ABSENT = 0;
tREWARD_X = 32;
tREWARD_Y = 33;
tREWARD_RT = 34;
tTOTALRT = 35; %tCUE_RT3 + tCHOICE_RT
tCORRECTNESS = 36;		CORRECT = 1; WRONG = 0;
tCORRECTION_TRIAL = 37; YES = 1; NO = 0;
tCORRECTION_TRIAL_NUMBER = 38; 
tCUE_XAvg = 39;
tCUE_YAvg = 40;

%load .mat file
[thisMAT thisROOT dummy] = uigetfile(pwd);
load([thisROOT thisMAT]);
RatData = expData.respMat(:,expData.respMat(tCORRECTION_TRIAL,:) == 0 & expData.respMat(tCHOICE_RESP,:) == PRESENT); %Removes correction trials and aborted trials
    
%% Accuracy
Results = [];
Results.Accuracy = [nanmean(RatData(tCORRECTNESS,:)) nanmean(RatData(tCORRECTNESS,RatData(tCATEGORY,:)==1)) nanmean(RatData(tCORRECTNESS,RatData(tCATEGORY,:)==2))].* 100; %All, Category A, Category B

%% Reaction time
Results.ReactionTime = [nanmean(RatData(tTOTALRT,:)) nanmean(RatData(tTOTALRT,RatData(tCATEGORY,:)==1)) nanmean(RatData(tTOTALRT,RatData(tCATEGORY,:)==2)); ... %TotalRT (Cue phase + Choice phase): All, Category A, Category B 
                        nanmean(RatData(tSTAR_RT,:)) nanmean(RatData(tSTAR_RT,RatData(tCATEGORY,:)==1)) nanmean(RatData(tSTAR_RT,RatData(tCATEGORY,:)==2)); ... %Star RT: All, Category A, Category B
                        nanmean(RatData(tCUE_RT1,:)) nanmean(RatData(tCUE_RT1,RatData(tCATEGORY,:)==1)) nanmean(RatData(tCUE_RT1,RatData(tCATEGORY,:)==2)); ... %Star to 1st touch RT: All, Category A, Category B
                        nanmean(RatData(tCUE_RT2,:)) - nanmean(RatData(tCUE_RT1,:)) nanmean(RatData(tCUE_RT2,RatData(tCATEGORY,:)==1)) - nanmean(RatData(tCUE_RT1,RatData(tCATEGORY,:)==1)) nanmean(RatData(tCUE_RT2,RatData(tCATEGORY,:)==2)) - nanmean(RatData(tCUE_RT1,RatData(tCATEGORY,:)==2)); ... %1st touch to 2nd touch RT: All, Category A, Category B
                        nanmean(RatData(tCUE_RT3,:)) - nanmean(RatData(tCUE_RT2,:)) nanmean(RatData(tCUE_RT3,RatData(tCATEGORY,:)==1)) - nanmean(RatData(tCUE_RT2,RatData(tCATEGORY,:)==1)) nanmean(RatData(tCUE_RT3,RatData(tCATEGORY,:)==2)) - nanmean(RatData(tCUE_RT2,RatData(tCATEGORY,:)==2)); ... %2nd touch to 3rd touch RT: All, Category A, Category B
                        nanmean(RatData(tCHOICE_RT,:)) nanmean(RatData(tCHOICE_RT,RatData(tCATEGORY,:)==1)) nanmean(RatData(tCHOICE_RT,RatData(tCATEGORY,:)==2)); ... %3rd touch to Choice RT: All, Category A, Category B
                        nanmean(RatData(tREWARD_RT,:)) nanmean(RatData(tREWARD_RT,RatData(tCATEGORY,:)==1)) nanmean(RatData(tREWARD_RT,RatData(tCATEGORY,:)==2))]; %Choice to Reward RT: All, Category A, Category B

%% TouchSeparation
cx = 1024 / 2;

RatData(tCUE_XAvg, :) = nanmean(RatData([tCUE_X1 ; tCUE_X2 ; tCUE_X3], :), 1);
RatData(tCUE_YAvg, :) = nanmean(RatData([tCUE_Y1 ; tCUE_Y2 ; tCUE_Y3], :), 1);

XDiffMatTraining3 = [nanmean(RatData(tCUE_XAvg, RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X3, RatData(tCATEGORY, :) == LEFT & RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X3, RatData(tCATEGORY, :) ==  RIGHT & RatData(tCORRECTNESS, :) == CORRECT))] - cx;
XDiffMatTraining3 = XDiffMatTraining3 - XDiffMatTraining3(1);
XDiffMatTraining2 = [nanmean(RatData(tCUE_XAvg, RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X2, RatData(tCATEGORY, :) == LEFT & RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X2, RatData(tCATEGORY, :) ==  RIGHT & RatData(tCORRECTNESS, :) == CORRECT))] - cx;
XDiffMatTraining2 = XDiffMatTraining2 - XDiffMatTraining2(1);
XDiffMatTraining1 = [nanmean(RatData(tCUE_XAvg, RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X1, RatData(tCATEGORY, :) == LEFT & RatData(tCORRECTNESS, :) == CORRECT)) nanmean(RatData(tCUE_X2, RatData(tCATEGORY, :) ==  RIGHT & RatData(tCORRECTNESS, :) == CORRECT))] - cx;
XDiffMatTraining1 = XDiffMatTraining1 - XDiffMatTraining1(1);
                      
Results.TouchSeparation = [XDiffMatTraining1(3) - XDiffMatTraining1(2) XDiffMatTraining2(3) - XDiffMatTraining2(2) XDiffMatTraining3(3) - XDiffMatTraining3(2)]; %Touch Separation according to the 1st touch, 2nd touch, and 3rd touch

%% Response Bias
Results.ResponseBias = jkGetBias(RatData(tCHOICE_SIDE,:));

%% Plot
figure('Position',[200 200 900 600]); 

%Accuracy
subplot(2,2,1);
bar(Results.Accuracy); ylabel(['Accuracy (%)']); xticklabels({'All' 'Category A' 'Category B'}); title(['Accuracy']); ylim([min(Results.Accuracy) - 10 max(Results.Accuracy) + 10]);

%Total reaction time
subplot(2,2,2);
bar(Results.ReactionTime(1,:)); ylabel(['Reaction Time (seconds)']); xticklabels({'All' 'Category A' 'Category B'}); title(['Reaction Time']); ylim([0 max(Results.ReactionTime(1,:)) + 1]);

%Touch Separation
subplot(2,2,3);
bar(Results.TouchSeparation); ylabel(['TouchSeparation (pixels)']); xlabel(['Touch Order']); xticklabels({'First' 'Second' 'Third'}); title(['Touch Separation']); ylim([min(Results.TouchSeparation) - 10 max(Results.TouchSeparation) + 10]);

%Response bias
subplot(2,2,4);
bar(Results.ResponseBias); ylabel(['Response Bias']); title(['Response Bias']); ylim([0 1]);
end %function SessionAnalysis

function [responseBias] = jkGetBias(inputMat);
	%Code by Jangjin Kim
	twoVals = [1 2];
	inputMat(isnan(inputMat)) = [];

	if numel(twoVals) > 2 | numel(twoVals) <= 0
		error;
	end	%numel(twoVals) > 2 | numel(twoVals) <= 0

	count1 = nansum(inputMat == twoVals(1));
	count2 = nansum(inputMat == twoVals(2));

	responseBias = abs(count1 - count2) / (count1 + count2);
end %[responseBias] = jkGetBias(inputMat);