function jkPutCue(screenH, filePath, szScreen, opt)
%Code by Jin Kim
cx = szScreen(2, 3) / 2; cy = szScreen(2, 4) / 2;

szHMARGIN = 205; szVMARGIN = 75;	%szHMARGIN was 195 in V2 [+10 px in V3]
szWIDTH = 238; szHEIGHT = 238;

cueLocMat = [(cx - (szWIDTH / 2)) / szScreen(2, 3) ... 
		(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
		szWIDTH / szScreen(2, 3) ... 
		szHEIGHT / szScreen(2, 4)];

choiceLocMat = [(cx - szHMARGIN - szWIDTH) / szScreen(2, 3) ... 
		(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
		szWIDTH / szScreen(2, 3) ... 
		szHEIGHT / szScreen(2, 4) ; ... 
			(cx + szHMARGIN) / szScreen(2, 3) ... 
			(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
			szWIDTH / szScreen(2, 3) ... 
			szHEIGHT / szScreen(2, 4)];

set(0, 'CurrentFigure', screenH);

thisCueImg = imread([filePath]);
if opt == 1	%center
	hold on;
		axes('Position', cueLocMat); imshow(thisCueImg);
	hold off;
elseif opt == 2 %Choice (left and right)
	hold on;
		axes('Position', choiceLocMat(1, :)); imshow(thisCueImg);
		axes('Position', choiceLocMat(2, :)); imshow(thisCueImg);
	hold off;
elseif opt == 3 %Choice- Left
    hold on;
		axes('Position', choiceLocMat(1, :)); imshow(thisCueImg);
	hold off;
elseif opt == 4 %Choice- Right
    hold on;
		axes('Position', choiceLocMat(2, :)); imshow(thisCueImg);
	hold off;
end	%opt == 1	%center