%Code by Jin Kim

%Screen parameters
maxCOL = 255;
colScreen = [200 200 200] ./ maxCOL;
colLIGHT = [255 255 255] ./ maxCOL; 
colDARK = [0 0 0] ./ maxCOL;

idScreen = Screen('Screens'); mainScreenID = 2;
szScreen1 = Screen(idScreen(1 + 1), 'Rect');	%control screen
szScreen2 = Screen(idScreen(1 + 2), 'Rect');	%show screen

if szScreen1(1, 3) > szScreen2(1, 3)
	szScreen(1, :) = szScreen1;		%control screen
	szScreen(2, :) = szScreen2;		%show screen
	mainScreenID = 2;
else
	szScreen(1, :) = szScreen2;		%show screen
	szScreen(2, :) = szScreen1;		%control screen
	mainScreenID = 1;
end	%szScreen1(1, 3) > szScreen2(1, 3)
clear szScreen1 szScreen2;

mainScreenPosition = [szScreen(1, 3) + 1 szScreen(1, 4) - szScreen(2, 4) szScreen(2, 3) szScreen(2, 4)];

cx = szScreen(2, 3) / 2; cy = szScreen(2, 4) / 2;

%InitStim def
szVMARGININIT = 135;

stepRAD = 20; nSTEPRAD = 4; modiFOC = 0; nCenterModi = 2.7;
basicStarCoord = -90:(720 / 5):(720 - 90);
thisStarX = cosd(basicStarCoord) .* (stepRAD * nSTEPRAD) + cx;
thisStarY = sind(basicStarCoord) .* (stepRAD * nSTEPRAD) + cy + szVMARGININIT;
StarBoundary = [min(thisStarX) min(thisStarY) max(thisStarX) max(thisStarY)];
InitStimLocMat = StarBoundary;

%TaskStim def
szHMARGIN = 205; szVMARGIN = 75;	%szHMARGIN was 195 in V2 [+10 px in V3]
szWIDTH = 238; szHEIGHT = 238;

TaskStimCenterLocMat = [cx - szWIDTH / 2 cy + szVMARGIN cx + szWIDTH / 2 cy + szVMARGIN + szHEIGHT];
TaskStimLocMat = [cx - szHMARGIN - szWIDTH cy + szVMARGIN cx - szHMARGIN cy + szVMARGIN + szHEIGHT ; ... 
			cx + szHMARGIN cy + szVMARGIN cx + szHMARGIN + szWIDTH cy + szVMARGIN + szHEIGHT];

%TargStim def.
colTARGSTIM = colLIGHT; %(colLIGHT - colDARK) ./ 2;

%Prep. screens
figScreens = figure('Color', colScreen, 'Position', mainScreenPosition, 'Pointer', 'custom', 'PointerShapeCData', pointerCol, 'menubar', 'none', 'resize', 'off', 'Name', ['Screen1' ], 'Visible', 'on');
	subplot('Position', [0 0 1 1], 'Color', colScreen)
	set(gca, 'XLim', [0 szScreen(2, 3)], 'YLim', [0 szScreen(2, 4)], 'XTick', [], 'YTick', []); axis off;