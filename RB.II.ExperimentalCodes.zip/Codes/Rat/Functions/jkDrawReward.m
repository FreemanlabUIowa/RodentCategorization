function jkDrawStar(screenH, cx, cy, whichSide)

%Star param
colLIGHT = [1 1 1]; colDARK = [0 0 0];

szHMARGIN = 205; szVMARGIN = 75;	%szHMARGIN was 195 in V2 [+10 px in V3]
szWIDTH = 238; szHEIGHT = 238;

TaskStimLocMat = [cx - szHMARGIN - szWIDTH cy + szVMARGIN cx - szHMARGIN cy + szVMARGIN + szHEIGHT ; ... 
			cx + szHMARGIN cy + szVMARGIN cx + szHMARGIN + szWIDTH cy + szVMARGIN + szHEIGHT];

set(0, 'CurrentFigure', screenH);

hold on;
	fill([TaskStimLocMat(whichSide, 1) TaskStimLocMat(whichSide, 3) TaskStimLocMat(whichSide, 3) TaskStimLocMat(whichSide, 1) TaskStimLocMat(whichSide, 1)], ... 
		[TaskStimLocMat(whichSide, 2) TaskStimLocMat(whichSide, 2) TaskStimLocMat(whichSide, 4) TaskStimLocMat(whichSide, 4) TaskStimLocMat(whichSide, 2)], ... 
		colLIGHT, 'EdgeColor', 'none');
hold off;