function fShaping(SIO, strRatID, shapingMODE, mouseMODE)
%shaping phase 1 and 2
%Code by Jangjin Kim, 2016-Sep-16

clc;

%Changeable parameters
ITIMat = 5:10;
initTIMEMAX = 15;
targTIMEMAX = 45;

%Parameters
relayLIGHT = 1; relayFEEDER = 2;
statusON = 1; statusOFF = 0;
strRatID = ['r' strRatID];
if mouseMODE == 0, pointerCol = nan(16, 16);
else pointerCol = ones(16, 16); end	%mouseMODE == 0
ScreenParams;

%shaping mode
txtShapingMODE = {['Auto-Whole'] ; ['Auto-Stim'] ; ['Touch']};

%Trial information
tINDEX = 1;
tRNDINDEX = 2;
tSTIMLOC = 3;		nSTIMLOC = 2; LEFT = 1; RIGHT = 2;
tRESPONSE = 4;		PRESENT = 1; ABSENT = 0;

%number of trials
nBLOCK = 30;
nBLKTRIALS = nSTIMLOC;
nTRIALS = nBLKTRIALS * nBLOCK;	%60 trials

%generate trials
trialMat = nan(tRESPONSE, nSTIMLOC, nBLOCK);
for blockRUN = 1:1:nBLOCK
	trialMat(tINDEX, :, blockRUN) = 1:nBLKTRIALS;
	trialMat(tRNDINDEX, :, blockRUN) = randperm(nBLKTRIALS);
	trialMat(tSTIMLOC, :, blockRUN) = mod(floor((trialMat(tRNDINDEX, :, blockRUN) - 1) / (nBLKTRIALS / nSTIMLOC)), nSTIMLOC) + 1;
end	%blockRUN = 1:1:nBLOCK
trialMat = reshape(trialMat, tRESPONSE, nTRIALS);
trialMat(tINDEX, :) = 1:nTRIALS;

%Key params
IsOut = KbName(']'); outFlag = false; modiTRIALRUN = 0;

%Start Experiment
try jkControlRelay(SIO, relayLIGHT, statusON); catch; end
SetMouse(mainScreenPosition(1) + mainScreenPosition(3) / 2, mainScreenPosition(4) / 2);

expSTART = GetSecs; startTIME = clock; startTIME = [num2str(startTIME(4)) ':' num2str(startTIME(5))];
for trialRUN = 1:1:nTRIALS
	%calculation & preparation for the trial
	%determine ITI
	ITIidx = randperm(length(ITIMat)); ITI = ITIMat(ITIidx(1));
	txtTRIALINFO = [strRatID ' ' num2str(trialRUN) ' / ' num2str(nTRIALS) ' [' txtShapingMODE{shapingMODE} '; ITI = ' num2str(ITI) '] StartTime: ' startTIME];

	%ITI
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), txtTRIALINFO, szScreen); drawnow expose;
	fprintf([txtTRIALINFO '\n']);
	go = true; thisITIOnset = GetSecs;
	while go
		ITITimeNow = GetSecs;
		FlushEvents('keyDown');
		[keyDown endSecs keyCode] = KbCheck;
		if keyDown
			if keyCode(IsOut)
				outFlag = true; go = false;
			end	%keyCode(IsOut)
		end	%keyDown

		if (ITITimeNow - thisITIOnset) >= ITI
			go = false;
		end	%(ITITimeNow - thisITIOnset) >= ITI
	end	%go

	%Star
	if outFlag == false
		jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), txtTRIALINFO, szScreen); jkDrawStar(figScreens(1), cx, cy, szVMARGININIT); drawnow expose;
		thisInitStimOnset = GetSecs;
		go = true;
		while go
			initTimeNow = GetSecs;
			[initX initY initCLICK] = GetMouse(mainScreenID);

			if shapingMODE == 1	%AUTO-Whole
				if (IsInRect(initX, initY, szScreen(2, :)) & any(initCLICK)) | ((initTimeNow - thisInitStimOnset) >= initTIMEMAX)
					go = false; pause(.2);
				end	%(IsInRect(initX, initY, InitStimLocMat) & any(initCLICK)) | ((initTimeNow - thisInitStimOnset) >= initTIMEMAX)
			elseif shapingMODE == 2	%AUTO-Stim
				if (IsInRect(initX, initY, InitStimLocMat) & any(initCLICK)) | ((initTimeNow - thisInitStimOnset) >= initTIMEMAX)
					go = false; pause(.2);
				end	%(IsInRect(initX, initY, InitStimLocMat) & any(initCLICK)) | ((initTimeNow - thisInitStimOnset) >= initTIMEMAX)
			end	%shapingMODE == 0
		end	%go
	else
		modiTRIALRUN = 1; break; 
	end	%outFlg == false

	%Reward-screen
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), txtTRIALINFO, szScreen); jkDrawReward(figScreens(1), cx, cy, trialMat(tSTIMLOC, trialRUN)); drawnow expose;
	thisTargStimOnset = GetSecs; if shapingMODE == 1 WaitSecs(.25); end

	go = true;
	while go
		targTimeNow = GetSecs;
		[targX targY targCLICK] = GetMouse(mainScreenID);

		if shapingMODE == 1
			if ((targTimeNow - thisTargStimOnset) >= targTIMEMAX)
				trialMat(tRESPONSE, trialRUN) = ABSENT;
				go = false;
			else
				if (IsInRect(targX, targY, szScreen(2, :)) & any(targCLICK))
					trialMat(tRESPONSE, trialRUN) = PRESENT;
					try jkControlRelay(SIO, relayFEEDER, statusON); catch; end
					go = false; pause(.2);
				end	%(IsInRect(targX, targY, szScreen) & any(targCLICK))
			end	%((targTimeNow - thisTargStimOnset) >= targTIMEMAX)
		elseif shapingMODE == 2	%AUTO-Stim
			if ((targTimeNow - thisTargStimOnset) >= targTIMEMAX)
				trialMat(tRESPONSE, trialRUN) = ABSENT;
				go = false;
			else
				if (IsInRect(targX, targY, TaskStimLocMat(trialMat(tSTIMLOC, trialRUN), :)) & any(targCLICK))
					trialMat(tRESPONSE, trialRUN) = PRESENT;
					try jkControlRelay(SIO, relayFEEDER, statusON); catch; end
					go = false; pause(.2);
				end	%(IsInRect(targX, targY, TaskStimLocMat(trialMat(tSTIMLOC, trialRUN), :)) & any(targCLICK))
			end	%((targTimeNow - thisTargStimOnset) >= targTIMEMAX)
		end	%shapingMODE == 1
	end	%go

	%ITI-screen
	jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), txtTRIALINFO, szScreen); drawnow expose;
end	%trialRUN = 1:1:nTRIALS
expEND = GetSecs; pause(1);
for figRUN = 1:1:nFIGS close(figScreens(figRUN)); end
try jkControlRelay(SIO, relayLIGHT, statusOFF); catch; end

disp([strRatID '-GaborPatches-' txtShapingMODE{shapingMODE} ' done!']);
disp(['Time ellapsed: ' num2str((expEND - expSTART) / 60) ' (min) Trial done: ' num2str(nansum(trialMat(tRESPONSE, :))) ' / ' num2str(nTRIALS)]);

picID = figure('Color', [1 1 1], 'Position', mainScreenPosition, 'menubar', 'none');
title(['This is to prevent ' strRatID ' from restarting the session']); axis off;
end	%fShapingV3(strRatID, shapingMODE, mouseMODE)