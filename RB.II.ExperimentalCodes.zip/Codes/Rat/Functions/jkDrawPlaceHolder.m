function jkDrawPlaceHolder(screenH, cx, cy, whichSide)
colLIGHT = ones(1, 3); colDARK = zeros(1, 3); colBk = ones(1, 3) .* (200 / 255);

szHMARGIN = 205; szVMARGIN = 75;
szWIDTH = 238; szHEIGHT = 238;

szLINEWIDTH = 30;

TaskStimLocMat = [cx - szWIDTH / 2 cy + szVMARGIN cx + szWIDTH / 2 cy + szVMARGIN + szHEIGHT ; ... 
			cx - szHMARGIN - szWIDTH cy + szVMARGIN cx - szHMARGIN cy + szVMARGIN + szHEIGHT ; ... 
			cx + szHMARGIN cy + szVMARGIN cx + szHMARGIN + szWIDTH cy + szVMARGIN + szHEIGHT];
TaskStimLocMat_inside = TaskStimLocMat + [1 1 -1 -1 ; 1 1 -1 -1 ; 1 1 -1 -1] .* szLINEWIDTH;

whichSide = whichSide + 1;

set(0, 'CurrentFigure', screenH);
hold on;
	fill([TaskStimLocMat(whichSide, 1) TaskStimLocMat(whichSide, 3) TaskStimLocMat(whichSide, 3) TaskStimLocMat(whichSide, 1) TaskStimLocMat(whichSide, 1)], ... 
		[TaskStimLocMat(whichSide, 2) TaskStimLocMat(whichSide, 2) TaskStimLocMat(whichSide, 4) TaskStimLocMat(whichSide, 4) TaskStimLocMat(whichSide, 2)], ... 
		colDARK, 'EdgeColor', 'none');
	fill([TaskStimLocMat_inside(whichSide, 1) TaskStimLocMat_inside(whichSide, 3) TaskStimLocMat_inside(whichSide, 3) TaskStimLocMat_inside(whichSide, 1) TaskStimLocMat_inside(whichSide, 1)], ... 
		[TaskStimLocMat_inside(whichSide, 2) TaskStimLocMat_inside(whichSide, 2) TaskStimLocMat_inside(whichSide, 4) TaskStimLocMat_inside(whichSide, 4) TaskStimLocMat_inside(whichSide, 2)], ... 
		colBk, 'EdgeColor', 'none');
hold off;
end	%jkDrawPlaceHolder(screenH, cx, cy, whichSide)