function jkDrawStar(screenH, cx, cy, szVMARGININIT)

%Star param
colLIGHT = [1 1 1]; colDARK = [0 0 0];

stepRAD = 20; nSTEPRAD = 4; modiFOC = 0; nCenterModi = 2.7;
basicStarCoord = -90:(720 / 5):(720 - 90);
thisStarX = cosd(basicStarCoord) .* (stepRAD * nSTEPRAD) + cx;
thisStarY = sind(basicStarCoord) .* (stepRAD * nSTEPRAD) + cy + szVMARGININIT;
StarBoundary = [min(thisStarX) min(thisStarY) max(thisStarX) max(thisStarY)];

innerBasicStarCoord = -0:(360 / 5):(360 - 0);
innerStarX = sind(innerBasicStarCoord) .* (stepRAD * nSTEPRAD / nCenterModi) + cx;
innerStarY = cosd(innerBasicStarCoord) .* (stepRAD * nSTEPRAD / nCenterModi) + cy + szVMARGININIT;

set(0, 'CurrentFigure', screenH);

hold on;
	fill([min(thisStarX) max(thisStarX) max(thisStarX) min(thisStarX) min(thisStarX)], ... 
		[min(thisStarY) min(thisStarY) max(thisStarY) max(thisStarY) min(thisStarY)], colDARK, 'EdgeColor', 'none');
	fill(thisStarX, thisStarY, colLIGHT, 'EdgeColor', 'none');
	fill(innerStarX, innerStarY, colLIGHT, 'EdgeColor', colLIGHT, 'LineWidth', 2.5);
hold off;