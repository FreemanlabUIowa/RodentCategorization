function jkShowExpInfo(screenH, strINPUT, szScreen)
%Code by Jin Kim
set(0, 'CurrentFigure', screenH);

colLIGHT = [1 1 1]; colDARK = [0 0 0];
initTextX = 15; initTextY = 15; szFONT = 12.5;

hold on;
	text(initTextX, initTextY, strINPUT, 'FontSize', szFONT);
hold off;