%Code by Matthew B. Broschard
%12/01/19

function jkGenGabor(screenH, thisFreq, thisOrientation, szScreen, opt)

cx = szScreen(2, 3) / 2; cy = szScreen(2, 4) / 2;

szHMARGIN = 205; szVMARGIN = 75;
szWIDTH = 238; szHEIGHT = 238;

cueLocMat = [(cx - (szWIDTH / 2)) / szScreen(2, 3) ... 
		(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
		szWIDTH / szScreen(2, 3) ... 
		szHEIGHT / szScreen(2, 4)];

choiceLocMat = [(cx - szHMARGIN - szWIDTH) / szScreen(2, 3) ... 
		(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
		szWIDTH / szScreen(2, 3) ... 
		szHEIGHT / szScreen(2, 4) ; ... 
			(cx + szHMARGIN) / szScreen(2, 3) ... 
			(cy - szVMARGIN - szHEIGHT) / szScreen(2, 4) ... 
			szWIDTH / szScreen(2, 3) ... 
			szHEIGHT / szScreen(2, 4)];

gauSigma = 23.8; gauPhase = 2 * pi; gauTrim = .005;
X = 1:szWIDTH; X = (X ./ szWIDTH) - .5;
[Xm Ym] = meshgrid(X, X);
freq = thisFreq / szWIDTH * (szWIDTH / 6); 
Xf = X * freq * 2 * pi;
ori = (thisOrientation / 360) * 2 * pi;
XYori = [Xm * cos(ori) + Ym * sin(ori)];
XYf = XYori * freq * 2 * pi;
grating = sin(XYf + gauPhase);
gauS = gauSigma / szWIDTH;
thisGauss = ((((Xm.^2) + (Ym.^2)) .* (2 * gauS^2))); 
thisGauss(thisGauss < gauTrim) = gauTrim; thisGauss(thisGauss > gauTrim) = 0; 
thisCueImg = grating .* thisGauss;  thisCueImg = thisCueImg ./ max(max(thisCueImg)); thisCueImg = thisCueImg + (200 / 255);
set(0, 'CurrentFigure', screenH);

hold on;
	if opt == 1
		axes('Position', cueLocMat); imshow(thisCueImg);
	else
		axes('Position', choiceLocMat(1, :)); imshow(thisCueImg);
		axes('Position', choiceLocMat(2, :)); imshow(thisCueImg);
	end	%opt == 1
hold off;