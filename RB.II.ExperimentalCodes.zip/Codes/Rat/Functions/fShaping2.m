function fShaping2(SIO, strRatID, shapingMODE, mouseMODE)
%Shaping phase 3 and 4

clc;

%Shaping mode
shapingMODE = mod(shapingMODE - 1, 2) + 1;
txtShapingMODE = {['Touch-No time limit'] ; ['Touch-With time limit']};

%Changable parameters
ITIMat = 5:10;      %Inter trial interval
nTouchRequired = 3; %number of touches during the cue phase
pauseTime = .2;		%.2 sec in b/w each touch

if shapingMODE == 1
	TimeLimit_Cue = Inf;	
    TimeLimit_Choice = Inf;
elseif shapingMODE == 2
	TimeLimit_Cue = 2;		%time limit per each event
    TimeLimit_Choice = 2;		%time limit per each event
end	%shapingMODE == 1

%Parameters
relayLIGHT = 1; relayFEEDER = 2;
statusON = 1; statusOFF = 0;
strRatID = ['r' strRatID];
if mouseMODE == 0, pointerCol = nan(16, 16);
else pointerCol = ones(16, 16); end	%mouseMODE == 0
ScreenParams;

%Trial information
tINDEX = 1;
tRNDINDEX = 2;
tSTIMLOC = 3;		nSTIMLOC = 2; LEFT = 1; RIGHT = 2;
tRESPONSE_1 = 4;	PRESENT = 1; ABSENT = 0;
tRESPONSE_1_RT = 5;	%from onset to 1st touch
tRESPONSE_2 = 6;	%PRESENT = 1; ABSENT = 0;
tRESPONSE_2_RT = 7;	%from onset to 2nd touch [not the time b/w 1st and 2nd]
tRESPONSE_3 = 8;	%PRESENT = 1; ABSENT = 0;
tRESPONSE_3_RT = 9;	%from onset to 3rd touch [not the time b/w 2nd and 3rd]
tRESPONSE_C = 10;	%PRESENT = 1; ABSENT = 0;
tRESPONSE_C_RT = 11;	%from choice onset to touch
tRESPONSE_R = 12;	%PRESENT = 1; ABSENT = 0;
tRESPONSE_R_RT = 13;   	%from reward onset to touch

%number of trials
nBLOCK = 30;
nBLKTRIALS = nSTIMLOC;
nTRIALS = nSTIMLOC * nBLOCK;

%generate trials
trialMat = nan(tRESPONSE_R_RT, nSTIMLOC, nBLOCK);
for blockRUN = 1:1:nBLOCK
	trialMat(tINDEX, :, blockRUN) = 1:nBLKTRIALS;
	trialMat(tRNDINDEX, :, blockRUN) = randperm(nBLKTRIALS);
	trialMat(tSTIMLOC, :, blockRUN) = mod(floor((trialMat(tRNDINDEX, :, blockRUN) - 1) / (nBLKTRIALS / nSTIMLOC)), nSTIMLOC) + 1;
end	%blockRUN = 1:1:nBLOCK
trialMat = reshape(trialMat, tRESPONSE_R_RT, nTRIALS);
trialMat(tINDEX, :) = 1:nTRIALS;

WaitSecs(.1);		%initial loading of mex files

%Key params
IsOut = KbName(']'); outFlag = false; modiTRIALRUN = 0;

%Start experiment
try jkControlRelay(SIO, relayLIGHT, statusON); catch; end
SetMouse(mainScreenPosition(1) + cx, cy);

respMat = [];		%similar to trialMat but it will have the information from all correction trials as well
expSTART = GetSecs; startTIME = clock; startTIME = [num2str(startTIME(4)) ':' num2str(startTIME(5))];
txtSTARTTime = ['StartTime: ' startTIME];

%% Start!
for trialRUN = 1:1:nTRIALS

	trialGO = true; correctionFlag = false;
	while trialGO
		ITIidx = randperm(length(ITIMat)); ITI = ITIMat(ITIidx(1));
		if correctionFlag == false
			txtTRIALINFO = [strRatID ' ' num2str(trialRUN) ' / ' num2str(nTRIALS) ' [' txtShapingMODE{shapingMODE} '; ITI = ' num2str(ITI)];
		else
			txtTRIALINFO = [strRatID ' ' num2str(trialRUN) ' / ' num2str(nTRIALS) ' Correction [' txtShapingMODE{shapingMODE} '; ITI = ' num2str(ITI)];
		end	%correctionFlag == false
		disp([txtTRIALINFO]);

		%initialize respMat
		thisRespMat = trialMat(:, trialRUN);

		%ITI
		jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO '] ' txtSTARTTime], szScreen); drawnow expose;
		go = true; thisITIOnset = GetSecs;
		while go
			ITITimeNow = GetSecs;
			FlushEvents('keyDown');
			[keyDown endSecs keyCode] = KbCheck;
			if keyDown
				if keyCode(IsOut)
					outFlag = true; go = false;
				end	%keyCode(IsOut)
			end	%keyDown

			if (ITITimeNow - thisITIOnset) >= ITI
				go = false;
			end	%(ITITimeNow - thisITIOnset) >= ITI
		end	%go(ITITimeNow - thisITIOnset) >= ITI

		%Star
		if outFlag == false
			thisRespMat([tRESPONSE_1 ; tRESPONSE_2 ; tRESPONSE_3 ; tRESPONSE_C ; tRESPONSE_R], 1) = ABSENT;

			jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - StarPhase] ' txtSTARTTime], szScreen); 
			jkDrawStar(figScreens(1), cx, cy, szVMARGININIT); drawnow expose; disp([' :: Star Phase']);

			go = true;
			while go
				[initX initY initCLICK] = GetMouse(mainScreenID);

				if (IsInRect(initX, initY, InitStimLocMat) & any(initCLICK))
					go = false;
				end	%(IsInRect(initX, initY, InitStimLocMat) & any(initCLICK))
			end	%go
		else
			modiTRIALRUN = 1; trialGO = false;
		end	%outFlag == false

		if trialGO == true
			%Cueing-phase
			%initialize params
			go = true; thisNTouch = 0; 
			jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - CueingPhase] ' txtSTARTTime], szScreen);
			jkDrawPlaceHolder(figScreens(1), cx, cy, 0); drawnow expose; disp([' :: Cueing Phase']); thisCueOnset = GetSecs;
			while go
				timeNow = GetSecs;
				[cueX cueY cueCLICK] = GetMouse(mainScreenID);
				if (IsInRect(cueX, cueY, TaskStimCenterLocMat) & any(cueCLICK)) & ((timeNow - thisCueOnset) <= TimeLimit_Cue) & thisNTouch <= nTouchRequired
					thisCueTouch = GetSecs; thisNTouch = thisNTouch + 1;
					thisRespMat(tRESPONSE_1 + (thisNTouch - 1) * 2, 1) = PRESENT;
					thisRespMat(tRESPONSE_1_RT + (thisNTouch - 1) * 2, 1) = (thisCueTouch - thisCueOnset);

					if shapingMODE == 1
						pause(pauseTime);
					else
						if (TimeLimit_Cue - (timeNow - thisCueOnset)) >= pauseTime
							pause(pauseTime);
						else
							pause(TimeLimit_Cue - (timeNow - thisCueOnset));
						end	%(TimeLimit_Cue - (timeNow - thisCueOnset)) >= pauseTime
					end	%shapingMODE == 1
				end	%(IsInRect(cueX, cueY, TaskStimCenterLocMat) & any(cueCLICK)) & ((timeNow - thisCueOnset) <= TimeLimit_Cue) & thisNTouch <= nTouchRequired

				if shapingMODE == 1	%no time limit
					if (thisNTouch >= nTouchRequired)
						go = false;
					end	%(thisNTouch >= nTouchRequired)
				elseif shapingMODE == 2
					if (thisNTouch >= nTouchRequired) | ((timeNow - thisCueOnset) >= TimeLimit_Cue)
						go = false;
					end	%(thisNTouch >= nTouchRequired) | ((timeNow - thisCueOnset) >= TimeLimit_Cue)
				end	%shapingMODE == 1
			end	%go

			if shapingMODE == 2	%with time-limit; stimulus will stay until 2 secs ellapsed
				TimeNow = GetSecs;
				WaitSecs(TimeLimit_Cue - (TimeNow - thisCueOnset));		%if it's negative, there would be no waiting
			end	%shapingMODE == 2	%with time-limit; stimulus will stay until 2 secs ellapsed

			%Choice-phase
			if (thisRespMat(tRESPONSE_3, 1) == PRESENT) & (thisNTouch >= nTouchRequired)
				go = true; thisNTouch = 0;
				jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - ChoicePhase] ' txtSTARTTime], szScreen);
				jkDrawPlaceHolder(figScreens(1), cx, cy, thisRespMat(tSTIMLOC, 1)); drawnow expose; disp([' :: Choice Phase']); thisChoiceOnset = GetSecs;
				while go
					timeNow = GetSecs;
					[choiceX choiceY choiceCLICK] = GetMouse(mainScreenID);
					if (IsInRect(choiceX, choiceY, TaskStimLocMat(thisRespMat(tSTIMLOC, 1), :)) & any(choiceCLICK)) & thisNTouch == 0
						thisChoiceTouch = GetSecs;
						thisRespMat(tRESPONSE_C, 1) = PRESENT;
						thisRespMat(tRESPONSE_C_RT, 1) = thisChoiceTouch - thisChoiceOnset;

						thisNTouch = thisNTouch + 1;
					end	%(IsInRect(choiceX, choiceY, TaskStimLocMat(thisRespMat(tSTIMLOC, 1), :)) & any(choiceCLICK)) & thisNTouch == 0

					if shapingMODE == 1	%no time limit
						if thisNTouch >= 1
							go = false;
						end	%thisNTouch >= 1
					elseif shapingMODE == 2
						if (thisNTouch >= 1) | ((timeNow - thisChoiceOnset) >= TimeLimit_Choice)
							go = false;
						end	%(thisNTouch >= 1) | ((timeNow - thisChoiceOnset) >= TimeLimit_Choice)
					end	%shapingMODE == 1	%no time limit
				end	%go

				if shapingMODE == 2	%with time-limit; stimulus will stay until 2 secs ellapsed
					TimeNow = GetSecs;
					WaitSecs(TimeLimit_Choice - (TimeNow - thisChoiceOnset));		%if it's negative, there would be no waiting
				end	%shapingMODE == 2	%with time-limit; stimulus will stay until 2 secs ellapsed
			end	%(thisRespMat(tRESPONSE_3, 1) == PRESENT) & (thisNTouch >= nTouchRequired)

			%Reward-phase
			if (thisRespMat(tRESPONSE_C, 1) == PRESENT) & (thisNTouch >= 1)
				SetMouse(mainScreenPosition(1) + cx, cy);
				jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - RewardPhase] ' txtSTARTTime], szScreen);
				jkDrawReward(figScreens(1), cx, cy, trialMat(tSTIMLOC, trialRUN)); drawnow expose; disp([' :: Reward Phase']); thisRewardOnset = GetSecs;
				go = true;
				while go
					[targX targY targCLICK] = GetMouse(mainScreenID);
					if (IsInRect(targX, targY, TaskStimLocMat(thisRespMat(tSTIMLOC, 1), :)) & any(targCLICK))
						thisRewardTouch = GetSecs;
						thisRespMat(tRESPONSE_R, 1) = PRESENT;
						thisRespMat(tRESPONSE_R_RT, 1) = thisRewardTouch - thisRewardOnset;
						try jkControlRelay(SIO, relayFEEDER, statusON); catch; end
						go = false; trialGO = false;
					end	%(IsInRect(targX, targY, TaskStimLocMat(trialMat(tSTIMLOC, trialRUN), :)) & any(targCLICK))
				end	%go
			end	%(thisRespMat(tRESPONSE_C, 1) == PRESENT) & (thisNTouch >= 1)

			%Clear screen
			jkCleanFigScreen(figScreens(1), colScreen, szScreen);

			%Update respMat
			respMat = [respMat thisRespMat]; clear thisRespMat;

			%Update correction flag
			correctionFlag = true;
		end	%trialGO == true
	end	%trialGO
	if modiTRIALRUN == 1 break; end
end	%trialRUN = 1:1:nTRIALS

expEND = GetSecs; pause(1); 
save(['respMat.mat'], 'respMat');
for figRUN = 1:1:nFIGS close(figScreens(figRUN)); end
try jkControlRelay(SIO, relayLIGHT, statusOFF); catch; end

picID = figure('Color', [1 1 1], 'Position', mainScreenPosition, 'menubar', 'none');
title(['This is to prevent ' strRatID ' from restarting the session']); axis off;
end	%fShapingEphys(SIO, strRatID, chID, shapingMODE, mouseMODE)