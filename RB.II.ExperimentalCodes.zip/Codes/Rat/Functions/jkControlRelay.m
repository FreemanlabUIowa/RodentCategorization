function jkControlRelay(SIO, relayID, relaySTATUS)
%
%Jangjin Kim, 2013-June-18

fopen(SIO);
	if relayID == 1		%LIGHT
		fwrite(SIO, [254 relaySTATUS]);
	elseif relayID == 2	%FEEDER
		fwrite(SIO, [254 2]);
		pause(.25);			%for some feeders which are sensitive to deliver 2 pellets, it should be commented
		fwrite(SIO, [254 3]);
	end	%relayID == 1		%LIGHT
fclose(SIO);
end