function jkCleanFigScreen(screenH, colScreen, szScreen)

%set(0, 'CurrentFigure', screenH); 
clf;
subplot('Position', [0 0 1 1], 'Color', colScreen)
set(gca, 'XLim', [0 szScreen(2, 3)], 'YLim', [0 szScreen(2, 4)], 'XTick', [], 'YTick', [], 'YDir', 'rev'); axis off;