%Code by Matthew B. Broschard
%12/01/19
%Inputs needed
%SIO
%strRatID: RatID
%sessionMODE- Shaping: 1-4, Training: 5, Testing: 6

function fTraining_and_Testing(SIO, strRatID, sessionMODE, mouseMODE)
clc;

%Changeable parameters
nTouchRequired = 3;                         %number of required touches during the cue phase
maxCT = 2;                                  %maximum number of consecutive correction trials on a given trial
ITIMat = 5:10;                              %Inter trial interval
TimeLimitedVersion = 0; YES = 1; NO = 0;    %If yes, then use TimeLimit_Cue & TimeLimit_Choice
TimeLimit_Cue = 2;                          %Time limit for Cue phase (seconds)
TimeLimit_Choice = 2;                       %Time limit for Choice phase (seconds)

%Task Type
thisTASKTYPE = mod(floor((str2num(strRatID) - 1) / 2), 2) + 1;
if thisTASKTYPE == 1, txtTaskType = ['RB'];      %Rule-based
elseif thisTASKTYPE == 2, txtTaskType = ['II'];  %Information integration
end %if thisTASKTYPE == 1

%Subgroup
thisSUBGROUP = mod(floor((str2num(strRatID) - 1) / 1), 4) + 1;
if thisSUBGROUP == 1, txtSubGroup = ['RBF'];     %Rule-based task, Frequency is the relevant dimension
elseif thisSUBGROUP == 2, txtSubGroup = ['RBO']; %Rule-based task, Orientation is the relevant dimension
elseif thisSUBGROUP == 3, txtSubGroup = ['IIP']; %Information integration task, positive slope
elseif thisSUBGROUP == 4, txtSubGroup = ['IIN']; %Information integration, negative slope
end %if thisSUBGROUP == 1

%Session Type
sessionMODE = sessionMODE - 4;
TRAINING = 1; TESTING = 2; 
txtSessionMODE = {['Training'] ; ['Testing']};

%mouseMODE
if mouseMODE == 0, pointerCol = nan(16, 16);
else pointerCol = ones(16, 16); end	%mouseMODE == 0

%Parameters
relayLIGHT = 1; relayFEEDER = 2;
statusON = 1; statusOFF = 0;
strRatID = ['r' strRatID];       
ScreenParams;
pauseTime = .2;		%.2 sec in b/w each touch
IsOut = KbName(']'); outFlag = false; modiTRIALRUN = 0;
Cat = {['A'], ['B']};

%Trial information
tINDEX = 1; %1:nTRIALS
tTASKTYPE = 2; RB = 1; II = 2;
tSUBGROUP = 3; RBF = 1; RBO = 2; IIP = 3; IIN = 4;
tFREQUENCY = 4;
tORIENTATION = 5;
tCATEGORY = 6; nCATEGORY = 2; CatA = 1; CatB = 2;
tRELEVANT_DISTANCE = 7;
tIRRELEVANT_DISTANCE = 8;
tRNDINDEX = 9;
tCORRECTSIDE = 10;  LEFT = 1; RIGHT = 2;
tSTAR_X = 11;
tSTAR_Y = 12;
tSTAR_RT = 13;
tCUE_RESP1 = 14; PRESENT = 1; ABSENT = 0;
tCUE_X1 = 15;
tCUE_Y1 = 16;
tCUE_RT1 = 17;			%CueOnset to 1stTouch
tCUE_RESP2 = 18; PRESENT = 1; ABSENT = 0;
tCUE_X2 = 19;
tCUE_Y2 = 20;
tCUE_RT2 = 21;			%CueOnset to 2ndTouch
tCUE_RESP3 = 22; PRESENT = 1; ABSENT = 0;
tCUE_X3 = 23;
tCUE_Y3 = 24;
tCUE_RT3 = 25;			%CueOnset to 3rdTouch
tCHOICE_RESP = 26; PRESENT = 1; ABSENT = 0;
tCHOICE_X = 27;
tCHOICE_Y = 28;
tCHOICE_RT = 29;
tCHOICE_SIDE = 30;		LEFT = 1; RIGHT = 2;
tREWARD_RESP = 31; PRESENT = 1; ABSENT = 0;
tREWARD_X = 32;
tREWARD_Y = 33;
tREWARD_RT = 34;
tTOTALRT = 35; %tCUE_RT3 + tCHOICE_RT
tCORRECTNESS = 36;		CORRECT = 1; WRONG = 0;
tCORRECTION_TRIAL = 37; YES = 1; NO = 0;
tCORRECTION_TRIAL_NUMBER = 38; 

%Get stimuli
nTRIALS = 80; Visualize = 0; Matrix = 1;
if sessionMODE == TRAINING, XSD = 2.5; 
elseif sessionMODE == TESTING, XSD = 10;end
Stimuli = GenerateDistributions(thisSUBGROUP, nTRIALS, XSD, Visualize, Matrix);

%Fill in trialMat
respMat = [];
trialMat = nan(38, nTRIALS);
trialMat(tINDEX, :) = 1:nTRIALS; 
trialMat(tTASKTYPE, :) = thisTASKTYPE; 
trialMat(tSUBGROUP, :) = thisSUBGROUP;
trialMat(tFREQUENCY : tRNDINDEX,:) = Stimuli; 
trialMat(tCORRECTSIDE,:) = trialMat(tCATEGORY,:);

%expData
expData.ProgramID = ['GaborPatches'];
expData.RatID = strRatID;
expData.date = date;
expData.time_st = clock;
expData.time_st = [num2str(expData.time_st(4)) ':' num2str(expData.time_st(5))];
expData.nTouch = nTouchRequired;
expData.Correction = 1;	%all the time
expData.TaskType = thisTASKTYPE;
expData.TxtTaskType = txtTaskType;
expData.SubGroup = thisSUBGROUP;
expData.TxtSubGroup = txtSubGroup;
expData.SessionType = txtSessionMODE;
expData.TimeLimitedVersion = TimeLimitedVersion;

if sessionMODE == TRAINING 
    fnameMat = [expData.ProgramID '-Training-' txtSubGroup '-' expData.RatID '-' expData.date '.mat'];
elseif sessionMODE == TESTING
    fnameMat = [expData.ProgramID '-Testing-' txtSubGroup '-' expData.RatID '-' expData.date '.mat'];
end %if sessionMODE == TRAINING 

WaitSecs(.1);   %initial loading of mex files

%Start experiment
try jkControlRelay(SIO, relayLIGHT, statusON); catch; end %try jkControlRelay(SIO, relayLIGHT, statusON);
SetMouse(mainScreenPosition(1) + cx, cy);

expSTART = GetSecs; 
startTIME = clock; 
startTIME = [num2str(startTIME(4)) ':' num2str(startTIME(5))];
txtSTARTTime = ['StartTime: ' startTIME];

for trialRUN = 1:1:nTRIALS
    nCORRECTION_TRIALS = 0; CompletedCorrectionTrials = 0;                    
	trialGO = true; correctionFlag = false;
	while trialGO
		%initialize respMat
		thisRespMat = trialMat(:, trialRUN);
		ITIidx = randperm(length(ITIMat)); ITI = ITIMat(ITIidx(1));
		if correctionFlag == false %Normal trial
			txtTRIALINFO = [strRatID ' ' num2str(trialRUN) ' / ' num2str(nTRIALS) ' [' txtSubGroup '; Category' Cat{trialMat(tCATEGORY,trialRUN)} '; Frequency: ' df2str(trialMat(tFREQUENCY,trialRUN),2) '; Orientation: ' df2str(trialMat(tORIENTATION,trialRUN),2) ' ITI = ' num2str(ITI) ']'];
            thisRespMat(tCORRECTION_TRIAL, 1) = NO;
        else %Correction trial
            txtTRIALINFO = [strRatID ' ' num2str(trialRUN) ' / ' num2str(nTRIALS) ' Correction! [' txtSubGroup '; Category' Cat{trialMat(tCATEGORY,trialRUN)} '; Frequency: ' df2str(trialMat(tFREQUENCY,trialRUN),2) '; Orientation: ' df2str(trialMat(tORIENTATION,trialRUN),2) ' ITI = ' num2str(ITI) ']'];
            thisRespMat(tCORRECTION_TRIAL, 1) = YES;
            nCORRECTION_TRIALS = nCORRECTION_TRIALS + 1;
            thisRespMat(tCORRECTION_TRIAL_NUMBER, 1) = nCORRECTION_TRIALS;
        end	%if correctionFlag == false %Normal trial
		disp([txtTRIALINFO]);

		%ITI
		jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO '] ' txtSTARTTime], szScreen); drawnow expose;
		go = true; thisITIOnset = GetSecs;
		while go
			ITITimeNow = GetSecs;
			FlushEvents('keyDown');
			[keyDown endSecs keyCode] = KbCheck;
			if keyDown
				if keyCode(IsOut)
					outFlag = true; go = false;
				end	%keyCode(IsOut)
			end	%keyDown

			if (ITITimeNow - thisITIOnset) >= ITI
				go = false;
			end	%(ITITimeNow - thisITIOnset) >= ITI
		end	%go(ITITimeNow - thisITIOnset) >= ITI

		%Star
		if outFlag == false
			thisRespMat([tCUE_RESP1 ; tCUE_RESP2 ; tCUE_RESP3 ; tCHOICE_RESP ; tREWARD_RESP], 1) = ABSENT;
			jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - StarPhase] ' txtSTARTTime], szScreen); 
			jkDrawStar(figScreens(1), cx, cy, szVMARGININIT); drawnow expose; disp([' :: Star Phase']);
            thisInitStimOnset = GetSecs;
			go = true;
			while go
				[initX initY initCLICK] = GetMouse(mainScreenID);
				if (IsInRect(initX, initY, InitStimLocMat) & any(initCLICK))
                    thisInitStimTouch = GetSecs;
                    thisRespMat(tSTAR_X, 1) = initX;
                    thisRespMat(tSTAR_Y, 1) = initY;
                    thisRespMat(tSTAR_RT, 1) = (thisInitStimTouch - thisInitStimOnset);
					go = false;
				end	%(IsInRect(initX, initY, InitStimLocMat) & any(initCLICK))
			end	%go
		else
			modiTRIALRUN = 1; trialGO = false;
		end	%outFlag == false

		if trialGO == true
			%Cueing-phase
			%initialize params
			go = true; thisNTouch = 0; 
			jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - CueingPhase] ' txtSTARTTime], szScreen);
			jkGenGabor(figScreens(1), trialMat(tFREQUENCY,trialRUN), trialMat(tORIENTATION,trialRUN), szScreen, 1); drawnow expose; disp([' :: Cueing Phase']); thisCueOnset = GetSecs;
			while go
				timeNow = GetSecs;
				[cueX cueY cueCLICK] = GetMouse(mainScreenID);
				if (IsInRect(cueX, cueY, TaskStimCenterLocMat) & any(cueCLICK)) & thisNTouch <= nTouchRequired
                    if TimeLimitedVersion == NO | (TimeLimitedVersion == YES & (timeNow - thisCueOnset) <= TimeLimit_Cue)
                        thisCueTouch = GetSecs; 
                        thisNTouch = thisNTouch + 1;
                        thisRespMat(tCUE_RESP1 + (thisNTouch - 1) * 4, 1) = PRESENT;
                        thisRespMat(tCUE_RT1 + (thisNTouch - 1) * 4, 1) = (thisCueTouch - thisCueOnset);
                        thisRespMat(tCUE_X1 + (thisNTouch - 1) * 4, 1) = cueX;
                        thisRespMat(tCUE_Y1 + (thisNTouch - 1) * 4, 1) = cueY;
                    end %if TimeLimitedVersion == NO | (TimeLimitedVersion == YES & (timeNow - thisCueOnset) <= TimeLimit_Cue)
				end	%(IsInRect(cueX, cueY, TaskStimCenterLocMat) & any(cueCLICK)) & ((timeNow - thisCueOnset) <= TimeLimit_Cue) & thisNTouch <= nTouchRequired

                if TimeLimitedVersion == 0 %No
                   pause(pauseTime); %This prevents a single touch to be registered as multiple touches
                   if thisNTouch >= nTouchRequired %Touch requirement has been reached, break while loop
                      go = false;
                   end %if thisNTouch >= nTouchRequired
                elseif TimeLimitedVersion == 1 %Yes
                    if (timeNow - thisCueOnset) >= TimeLimit_Cue - pauseTime %Here, pausing 'pauseTime' would cause the Cue phase to exceed TimeLimit_Cue
                       pause(TimeLimit_Cue - (timeNow - thisCueOnset)); %Pause the correct amount so that the Cue phase does not exceed TimeLimit_Cue
                    else
                       pause(pauseTime);
                    end %if (timeNow - thisCueOnset) >= TimeLimit_Cue - pauseTime
                    
                    timeNow = GetSecs;
                    if (timeNow - thisCueOnset) >= TimeLimit_Cue | thisNTouch >= nTouchRequired %TimeLimit_Cue is up! or 3 touches
                        go = false;
                        WaitSecs(TimeLimit_Cue - (TimeNow - thisCueOnset)); %Makes sure the Cue phase = TimeLimit_Cue even if TouchRequirement is met
                    end %if (timeNow - thisCueOnset) >= TimeLimit_Cue
                end %if TimeLimitedVersion == NO
			end	%go

			%Choice-phase
			if thisRespMat(tCUE_RESP3, 1) == PRESENT
				go = true; thisNTouch = 0;
				jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - ChoicePhase] ' txtSTARTTime], szScreen);
				jkGenGabor(figScreens(1), trialMat(tFREQUENCY,trialRUN), trialMat(tORIENTATION,trialRUN), szScreen, 0); drawnow expose; disp([' :: Choice Phase']); thisChoiceOnset = GetSecs;
				while go
					timeNow = GetSecs;
					[choiceX choiceY choiceCLICK] = GetMouse(mainScreenID);
                    if any(choiceCLICK) & thisNTouch == 0 & (IsInRect(choiceX, choiceY, TaskStimLocMat(1, :)) | IsInRect(choiceX, choiceY, TaskStimLocMat(2, :)))
                        thisChoiceTouch = GetSecs;
						thisRespMat(tCHOICE_RESP, 1) = PRESENT;
						thisRespMat(tCHOICE_RT, 1) = thisChoiceTouch - thisChoiceOnset;
                        thisRespMat(tTOTALRT, 1) = thisRespMat(tCHOICE_RT, 1) + thisRespMat(tCUE_RT3, 1);
                        if IsInRect(choiceX, choiceY, TaskStimLocMat(1, :)) %LEFT
                            thisRespMat(tCHOICE_SIDE,1) = LEFT;
                        elseif IsInRect(choiceX, choiceY, TaskStimLocMat(2, :)) %RIGHT
                            thisRespMat(tCHOICE_SIDE,1) = RIGHT;
                        end %if (IsInRect(choiceX, choiceY, TaskStimLocMat(1, :)) %LEFT
                        
                        if thisRespMat(tCHOICE_SIDE,1) == thisRespMat(tCORRECTSIDE,1)
                            thisRespMat(tCORRECTNESS,1) = CORRECT;
                            trialGO = false; %Trial done!
                        else
                            thisRespMat(tCORRECTNESS,1) = WRONG;
                            if sessionMODE == TRAINING
                                correctionFlag = true; %Correction trial initiated
                                 
                                 CompletedCorrectionTrials = CompletedCorrectionTrials + 1;
                                 if CompletedCorrectionTrials > maxCT
                                    trialGO = false;
                                 end %if CompletedCorrectionTrials > maxCT
                                 
                            elseif sessionMODE == TESTING %(No correction trials in testing)
                                trialGO = false;
                            end %if sessionMODE == TRAINING
                        end %if thisRespMat(tCHOICE_SIDE,1) == thisRespMat(tCORRECTSIDE,1)

						thisNTouch = thisNTouch + 1;
					end	%(IsInRect(choiceX, choiceY, TaskStimLocMat(thisRespMat(tCORRECTSIDE, 1), :)) & any(choiceCLICK)) & thisNTouch == 0

					if (thisNTouch >= 1)
						go = false;
                        if TimeLimitedVersion == YES
                            pause(TimeLimit_Choice - (TimeNow - thisChoiceOnset));
                        end
					end	%(thisNTouch >= 1) 
                    
                    if  TimeLimitedVersion == YES & ((timeNow - thisChoiceOnset) >= TimeLimit_Choice) %Choice phase exceeds TimeLimit_Choice
                        go = false;
                    end %if TimeLimitedVersion == 1 & ((timeNow - thisChoiceOnset) >= TimeLimit_Choice)
					
				end	%go 
			end	%if (thisRespMat(tCUE_RESP3, 1) == PRESENT)

			%Reward-phase
            if sessionMODE == TRAINING
                if (thisRespMat(tCHOICE_RESP, 1) == PRESENT) & thisRespMat(tCORRECTNESS, 1) == CORRECT
                    SetMouse(mainScreenPosition(1) + cx, cy);
                    jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - RewardPhase] ' txtSTARTTime], szScreen);
                    jkDrawReward(figScreens(1), cx, cy, trialMat(tCORRECTSIDE, trialRUN)); drawnow expose; disp([' :: Reward Phase']); thisRewardOnset = GetSecs;
                    go = true;
                    while go
                        [targX targY targCLICK] = GetMouse(mainScreenID);
                        if (IsInRect(targX, targY, TaskStimLocMat(thisRespMat(tCORRECTSIDE, 1), :)) & any(targCLICK))
                            thisRewardTouch = GetSecs;
                            thisRespMat(tREWARD_RESP, 1) = PRESENT;
                            thisRespMat(tREWARD_RT, 1) = thisRewardTouch - thisRewardOnset;
                            try jkControlRelay(SIO, relayFEEDER, statusON); catch; end
                            go = false;
                        end	%(IsInRect(targX, targY, TaskStimLocMat(trialMat(tSTIMLOC, trialRUN), :)) & any(targCLICK))
                    end	%go
                end	%if (thisRespMat(tCHOICE_RESP, 1) == PRESENT) & (thisNTouch >= 1) & thisRespMat(tCORRECTNESS, 1) == CORRECT
            elseif sessionMODE == TESTING
                if (thisRespMat(tCHOICE_RESP, 1) == PRESENT) & (thisNTouch >= 1)
                    SetMouse(mainScreenPosition(1) + cx, cy);
                    jkCleanFigScreen(figScreens(1), colScreen, szScreen); jkShowExpInfo(figScreens(1), [txtTRIALINFO ' - RewardPhase] ' txtSTARTTime], szScreen);
                    jkDrawReward(figScreens(1), cx, cy, trialMat(tCORRECTSIDE, trialRUN)); drawnow expose; disp([' :: Reward Phase']); thisRewardOnset = GetSecs;
                    go = true;
                    while go
                        [targX targY targCLICK] = GetMouse(mainScreenID);
                        if (IsInRect(targX, targY, TaskStimLocMat(thisRespMat(tCORRECTSIDE, 1), :)) & any(targCLICK))
                            thisRewardTouch = GetSecs;
                            thisRespMat(tREWARD_RESP, 1) = PRESENT;
                            thisRespMat(tREWARD_RT, 1) = thisRewardTouch - thisRewardOnset;
                            try jkControlRelay(SIO, relayFEEDER, statusON); catch; end
                            go = false;
                        end	%(IsInRect(targX, targY, TaskStimLocMat(trialMat(tSTIMLOC, trialRUN), :)) & any(targCLICK))
                    end	%go
                end	%if (thisRespMat(tCHOICE_RESP, 1) == PRESENT) & (thisNTouch >= 1)
            end %if sessionMODE == TRAINING
			%Clear screen
			jkCleanFigScreen(figScreens(1), colScreen, szScreen);

            %Update respMat
			respMat = [respMat thisRespMat]; clear thisRespMat;
		end	%trialGO == true
	end	%trialGO
    
	if modiTRIALRUN == 1, break; end %if modiTRIALRUN == 1
end	%trialRUN = 1:1:nTRIALS

expEND = GetSecs;

%Finish expData
expData.trialMat = trialMat;
expData.respMat = respMat;
expData.time_ed = clock;
expData.time_ed = [num2str(expData.time_ed(4)) ':' num2str(expData.time_ed(5))];
expData.duration = (expEND - expSTART) / 60;
save(fnameMat, 'expData');

pause(3); close(figScreens);
try jkControlRelay(SIO, relayLIGHT, statusOFF); catch; end %try jkControlRelay(SIO, relayLIGHT, statusOFF);

picID = figure('Color', [1 1 1], 'Position', mainScreenPosition, 'menubar', 'none');
title(['This is to prevent ' strRatID ' from restarting the session again']); axis off;

end	%function fTraining_and_Testing(SIO, strRatID, sessionMODE)