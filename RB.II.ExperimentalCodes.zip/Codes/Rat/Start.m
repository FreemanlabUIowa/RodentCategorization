function Start()
%
%Initiated by Matt Broschard, Nov/28/2018
%Reviewed by Jangjin Kim, Nov/28/2018
%
%

%ENDOF-----

%initialization
clear all; close all; fclose all; clc;

%Add exp functions to path
addpath([pwd '\Functions']);

%Set random seed
warning off; ClockRandSeed; warning on;

%Param def.
ProjectTitle = ['GaborPatches'];
authorINFO = ['MB & JK'];

%GUI space params
guiIniPosition = [350 450 500 280];

guiWIDTH = guiIniPosition(1, 3); guiHEIGHT = guiIniPosition(1, 4);
szMARGIN = 5; szXGAP = 3; szYGAP = szXGAP;
panelWIDTH = guiWIDTH - szMARGIN * 2; panelHEIGHT = guiHEIGHT - szMARGIN * 2;

%GUI & panel graphic params
typeTXT = ['Times New Roman']; szTXT = 12;
guibgCOL = ones(1, 3); panelbgCOL = [.75 .75 .5]; emphasbgCOL = [1 0 0];
alignHor = ['left'];

szCHARinPix = 7.5;
XstPix = 15; YstPix = panelHEIGHT - szYGAP; szYROW = 20;
YPixRowGap = 25;

%Default rat params
thisRatID = ['000'];
thisTOGLIGHT = 0;
thisTOGMOUSE = 0;

thisEXPMODE = 1;		%1~4 for shaping; 5 for training; 6 for testing

%Define serial port
%Serial port model information: RS-232 from IORelay.com
%Serial port is set to COM4 in this code, but it could be changed by your setup.
SIO = serial('COM4', 'Baudrate', 9600); fopen(SIO); fwrite(SIO, [254 3]); fclose(SIO);

%GUI start
guiID = figure('Color', guibgCOL, 'Position', guiIniPosition, 'resize', 'off', 'menubar', 'none', 'NumberTitle', 'off', 'Name', [ProjectTitle ' (code by ' authorINFO ')']);

hPanel = uipanel('Units', 'pixels', 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [szMARGIN szMARGIN panelWIDTH panelHEIGHT]);

txtRATID = ['RatID: ']; szIDSLOT = 7;
uicontrol('Parent', hPanel, 'Style', 'text', 'String', txtRATID, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [XstPix YstPix - YPixRowGap * 1 length(txtRATID) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor);
hEDIT_RatID = uicontrol('Parent', hPanel, 'Style', 'edit', 'String', thisRatID, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [XstPix + length(txtRATID) * szCHARinPix YstPix - YPixRowGap * 1 szIDSLOT * szCHARinPix szYROW], 'Callback', {@editRatID_Callback});

txtTOGLIGHT = {['Light OFF'] ; ['Light ON']}; TogStXPix = 350;
hTOGGLE_LIGHT = uicontrol('Parent', hPanel, 'Style', 'togglebutton', 'String', txtTOGLIGHT, 'Value', thisTOGLIGHT, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [TogStXPix YstPix - YPixRowGap * 1 (length(txtTOGLIGHT{1}) + szIDSLOT) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor, 'Callback', {@toggleLIGHT_Callback});

txtFEEDER = ['Test feeder'];
hPUSH_FEEDER = uicontrol('Parent', hPanel, 'Style', 'pushbutton', 'String', txtFEEDER, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [TogStXPix YstPix - YPixRowGap * 2 (length(txtTOGLIGHT{1}) + szIDSLOT) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor, 'Callback', {@pushFEEDER_Callback});

txtTOGMOUSE = {['Mouse OFF'] ; ['Mouse ON']}; TogStXPix = 350;
hTOGGLE_MOUSE = uicontrol('Parent', hPanel, 'Style', 'togglebutton', 'String', txtTOGMOUSE, 'Value', thisTOGMOUSE, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [TogStXPix YstPix - YPixRowGap * 3 (length(txtTOGLIGHT{1}) + szIDSLOT) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor, 'Callback', {@toggleMOUSE_Callback});

hPUSH_GO = uicontrol('Parent', hPanel, 'Style', 'pushbutton', 'String', ['Go!'], 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [TogStXPix YstPix - YPixRowGap * 8 (length(txtTOGLIGHT{1}) + szIDSLOT) * szCHARinPix (length(txtTOGLIGHT{1}) + szIDSLOT) * szCHARinPix], 'HorizontalAlignment', ['center'], 'Callback', {@pushGO_Callback});

txtEXPMODE = ['- Exp mode:']; txtTHISEXPMODE = {['Shaping: Auto-Whole'] ; ['Shaping: Auto-Stim'] ; ['Shaping: Touch-No time limit'] ; ['Shaping: Touch w/i time limit'] ; ['Training'] ; ['Testing']};

uicontrol('Parent', hPanel, 'Style', 'text', 'String', txtEXPMODE, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [XstPix YstPix - YPixRowGap * 2.75 length(txtEXPMODE) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor);
hPOPUP_ExpMode = uicontrol('Parent', hPanel, 'Style', 'popupmenu', 'String', txtTHISEXPMODE, 'Value', thisEXPMODE, 'FontName', typeTXT, 'FontSize', szTXT, 'BackgroundColor', panelbgCOL, 'Position', [XstPix + length(txtEXPMODE) * szCHARinPix YstPix - YPixRowGap * 2.5 (length(txtTHISEXPMODE{4}) + 3) * szCHARinPix szYROW], 'HorizontalAlignment', alignHor, 'Callback', {@popup_ExpMode});

	function editRatID_Callback(source, eventdata)
		thisRATID = get(hEDIT_RatID, 'String');
	end	%editRatID_Callback(source, eventdata)

	function toggleLIGHT_Callback(source, eventdata)
		thisTOGLIGHT = get(source, 'Value');
		set(hTOGGLE_LIGHT, 'Value', thisTOGLIGHT, 'String', txtTOGLIGHT{thisTOGLIGHT + 1});

		try jkControlRelay(SIO, 1, thisTOGLIGHT); catch; end
	end	%toggleLIGHT_Callback(source, eventdata)

	function pushFEEDER_Callback(source, eventdata)
		try jkControlRelay(SIO, 2, 1); catch; end
	end	%pushFEEDER_Callback(source, eventdata)

	function toggleMOUSE_Callback(source, eventdata)
		thisTOGMOUSE = get(source, 'Value');
		set(hTOGGLE_MOUSE, 'Value', thisTOGMOUSE, 'String', txtTOGMOUSE{thisTOGMOUSE + 1});
	end	%toggleMOUSE_Callback(source, eventdata)

	function popup_ExpMode(source, eventdata)
		thisEXPMODE = get(hPOPUP_ExpMode, 'Value');
		set(hPOPUP_ExpMode, 'Value', thisEXPMODE);
	end	%popup_ExpMode(source, eventdata)

	function pushGO_Callback(source, eventdata)
		editRatID_Callback;

		if get(hPOPUP_ExpMode, 'Value') <= 2
			fShaping(SIO, get(hEDIT_RatID, 'String'), get(hPOPUP_ExpMode, 'Value'), get(hTOGGLE_MOUSE, 'Value'));
		elseif get(hPOPUP_ExpMode, 'Value') == 3 | get(hPOPUP_ExpMode, 'Value') == 4
			fShaping2(SIO, get(hEDIT_RatID, 'String'), get(hPOPUP_ExpMode, 'Value'), get(hTOGGLE_MOUSE, 'Value')); 
		elseif get(hPOPUP_ExpMode, 'Value') >= 5
			fTraining_and_Testing(SIO, get(hEDIT_RatID, 'String'), get(hPOPUP_ExpMode, 'Value'),get(hTOGGLE_MOUSE, 'Value'));
        end	%get(hPOPUP_ExpMode, 'Value') < 2
	end	%pushGO_Callback(source, eventdata)
end	%EphysCatGaborPatches()