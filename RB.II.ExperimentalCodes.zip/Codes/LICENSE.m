%Permission is hereby granted, free of charge, to use, copy, and modify 
%these codes and associated documentation. All files are provided as is, 
%without warranty of any kind. We ask that the following publication be 
%cited in the event that the obtained codes are implemented in published work. 

%Broschard, M. B., Kim, J., Love, B. C., Wasserman, E. A., & Freeman, J. H. (2019). Selective attention in rat visual category learning. Learning & Memory, 26(3), 84�92. doi: 10.1101/lm.048942.118

%http://learnmem.cshlp.org/content/26/3/84.full
